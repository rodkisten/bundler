import type { CipoCssArtifact } from "@rodkisten/cipo";
import { DEVTOOLS_BUILD_BADGE, DEVTOOLS_BUILD_INFO } from "@rodkisten/devtools/core/build-info";
import { DevtoolsContext } from "@rodkisten/devtools/core/context";
import { debugLog } from "@rodkisten/devtools/core/debug";
import { component, event, html, renderInto, repeat, styled } from "@rodkisten/devtools/core/runtime";
import { icon } from "@rodkisten/devtools/core/utils";
import type { DevtoolsContextValue, DevtoolsShellRefs } from "@rodkisten/devtools/types";
import { filterArray, flatMap, joinArray, objectKeys } from "@rodkisten/nascente";


const ShellRoot = styled.div("RodDevtoolsShellRoot").css`
  min-width: 200px;
  pointer-events: none;
  position: fixed;
  inset: 0;
  z-index: var(--rd-z-container, 2147483510);
  -webkit-transform: translate3d(0, 0, 0);
  transform: translateZ(1px);
  isolation: isolate;
  contain: layout style paint;
  color: $foreground;
  font-family: $font.ui;
  font-size: var(--rd-ui-font-size, 14px);
  line-height: 1.35;
  direction: ltr;
  text-align: left;
  --rd-safe-top: env(safe-area-inset-top, 0px);
  --rd-safe-bottom: max(env(safe-area-inset-bottom, 0px), var(--rd-safe-area-minimum, 20px));
  --rd-visual-viewport-top: 0px;
  --rd-visual-viewport-height: 100dvh;

  &[data-inline="true"] {
    position: relative;
    width: 100%;
    height: 100%;
    min-height: 320px;
  }

  *,
  *::before,
  *::after {
    box-sizing: border-box;
    user-select: none;
    -webkit-user-select: none;
    -webkit-touch-callout: none;
    pointer-events: auto;
    -webkit-tap-highlight-color: transparent;
    -webkit-text-size-adjust: none;
  }

  input,
  textarea,
  pre,
  code,
  [contenteditable="true"],
  .cm-editor,
  .cm-content {
    user-select: text;
    -webkit-user-select: text;
    -webkit-touch-callout: default;
  }

  button,
  input,
  textarea,
  select {
    font: inherit;
    color: inherit;
  }

  button {
    appearance: none;
    border: 0;
    margin: 0;
  }
`;

const EntryButtonView = styled.button("RodDevtoolsEntryButton").css`
  touch-action: none;
  position: fixed;
  width: var(--rd-entry-button-size, $$entrySize);
  height: var(--rd-entry-button-size, $$entrySize);
  display: grid;
  place-items: center;
  border-radius: $panel;
  background: black;
  color: white;
  opacity: .6;
  z-index: var(--rd-z-entry, 2147483600);
  cursor: grab;
  user-select: none;
  font: 700 23px / 1 $font.ui;
  transition: opacity .3s, transform .15s;
  box-shadow: $shadow.entry;

  &:hover,
  &:active,
  &[data-active="true"] {
    opacity: .82;
  }

  &:active {
    cursor: grabbing;
    transform: scale(.96);
  }
`;

const DevtoolsDock = styled.section("RodDevtoolsDock").css`
  pointer-events: auto;
  position: absolute;
  left: 0;
  bottom: calc(var(--rd-safe-bottom) + var(--rd-dock-bottom-gap, 0px));
  width: 100%;
  height: min(
    calc(80% - var(--rd-safe-bottom)),
    calc(var(--rd-visual-viewport-height, 100dvh) - var(--rd-visual-viewport-top, 0px) - var(--rd-safe-top, env(safe-area-inset-top, 0px)) - var(--rd-safe-bottom) - 12px)
  );
  max-height: calc(var(--rd-visual-viewport-height, 100dvh) - var(--rd-visual-viewport-top, 0px) - var(--rd-safe-top, env(safe-area-inset-top, 0px)) - var(--rd-safe-bottom) - 12px);
  z-index: var(--rd-z-dock, 2147483520);
  display: block;
  visibility: hidden;
  padding-top: var(--rd-tab-height, $$tabHeight);
  opacity: 0;
  background: $background;
  border-top: 1px solid $border;
  box-shadow: $shadow.panel;
  transition: opacity var(--rd-animation-duration, 300ms);
  overflow: hidden;
  contain: layout style paint;
  backdrop-filter: blur(var(--rd-blur, 0px));

  &[data-active="true"] {
    visibility: visible;
    opacity: var(--rd-transparency, .95);
  }

  &[data-inline="true"] {
    position: absolute;
    bottom: 0;
    height: 100%;
    visibility: visible;
    opacity: 1;
  }
`;

const Resizer = styled.div("RodDevtoolsResizer").css`
  position: absolute;
  left: 0;
  top: calc(var(--rd-resizer-height, 30px) * -.6);
  width: 100%;
  height: var(--rd-resizer-height, 30px);
  touch-action: none;
  cursor: row-resize;
  z-index: var(--rd-z-resizer, 2147483590);

  &::after {
    content: "";
    display: block;
    width: var(--rd-resizer-handle-width, 64px);
    height: var(--rd-resizer-handle-height, 6px);
    margin: 12px auto 0;
    border-radius: $pill;
    background: mix($primary, transparent, 55%);
    box-shadow: $shadow.entry;
  }
`;

const Tabbar = styled.nav("RodDevtoolsTabbar").css`
  position: absolute;
  left: 0;
  right: 0;
  top: 0;
  height: var(--rd-tab-height, $$tabHeight);
  display: flex;
  align-items: stretch;
  overflow-x: auto;
  overflow-y: hidden;
  scrollbar-width: none;
  background: $backgroundDark;
  border-bottom: 1px solid $border;
  color: $primary;
  overscroll-behavior-x: contain;

  &::-webkit-scrollbar {
    display: none;
  }
`;


const ToolPanel = styled.section("RodDevtoolsToolPanel").css`
  position: absolute;
  inset: 0;
  width: 100%;
  height: 100%;
  overflow: hidden;
  background: $background;

  &[hidden] {
    display: none !important;
  }
`;

const TabButton = styled.button("RodDevtoolsTabButton").css`
  position: relative;
  flex: 0 0 auto;
  min-width: var(--rd-tab-min-width, 78px);
  height: var(--rd-tab-height, 40px);
  padding: 0 var(--rd-panel-gap, 10px);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  background: transparent;
  color: inherit;
  cursor: pointer;
  text-transform: capitalize;
  font-size: var(--rd-tab-font-size, 12px);
  white-space: nowrap;
  transition: color .2s, background .2s;

  &:hover {
    background: mix($highlight, transparent, 70%);
  }

  &[data-selected="true"] {
    color: $accent;
  }

  &[data-selected="true"]::after {
    content: "";
    position: absolute;
    left: 8px;
    right: 8px;
    bottom: 0;
    height: 2px;
    border-radius: 2px 2px 0 0;
    background: $accent;
  }

  x:not(xs) {
    min-width: var(--rd-compact-tab-min-width, 58px);
    padding-inline: 7px;
  }
`;

const TabIcon = styled.span("RodDevtoolsTabIcon").css`
  display: inline-grid;
  place-items: center;
  font-size: 15px;
  line-height: 1;

  .roderuda-lucide-icon {
    display: block;
    flex: 0 0 auto;
    stroke: currentColor;
  }

  x:not(xs) {
    font-size: 17px;
  }
`;

const TabLabel = styled.span("RodDevtoolsTabLabel").css`
  x:not(xs) {
    display: none;
  }
`;

const BuildBadge = styled.span("RodDevtoolsBuildBadge").css`
  position: sticky;
  right: 4px;
  align-self: center;
  flex: 0 0 auto;
  margin-inline: auto 6px;
  padding: 2px 6px;
  border: 1px solid $border;
  border-radius: $pill;
  background: mix($backgroundDark, transparent, 88%);
  color: $muted;
  font: 600 9px / 1.4 $font.mono;
  white-space: nowrap;
  pointer-events: auto;
  user-select: text;
`;

const Tools = styled.main("RodDevtoolsTools").css`
  position: relative;
  width: 100%;
  height: 100%;
  min-width: 0;
  min-height: 0;
  overflow: hidden;
`;

const Notifications = styled.div("RodDevtoolsNotifications").css`
  position: absolute;
  top: var(--rd-notification-top, 48px);
  left: 50%;
  z-index: var(--rd-z-notification, 2147483560);
  width: min(92%, var(--rd-notification-width, 440px));
  display: grid;
  gap: 7px;
  transform: translateX(-50%);
  pointer-events: none;
`;

const ModalRoot = styled.div("RodDevtoolsModalRoot").css`
  position: absolute;
  inset: 0;
  z-index: var(--rd-z-modal, 2147483570);
  display: none;
  place-items: center;
  padding: 16px;
  background: rgb(0 0 0 / .45);
  backdrop-filter: blur(2px);
  pointer-events: none;

  &[data-active="true"],
  &.roderuda-active {
    display: grid;
    pointer-events: auto;
  }
`;

const NotificationToast = styled.div("RodDevtoolsNotificationToast").css`
  pointer-events: auto;
  padding: 10px 12px;
  border: 1px solid $border;
  border-radius: $notification;
  color: $primary;
  background: mix($background, transparent, 94%);
  box-shadow: $shadow.notification;
  backdrop-filter: blur(14px);
  opacity: 0;
  transform: translateY(-7px) scale(.98);
  transition: opacity .18s ease-out, transform .18s ease-out;

  &[data-active="true"] {
    opacity: 1;
    transform: translateY(0) scale(1);
  }

  &[data-type="success"] {
    border-color: $success;
  }

  &[data-type="warning"] {
    border-color: $warningBorder;
    background: $warningBg;
    color: $warningFg;
  }

  &[data-type="error"] {
    border-color: $errorBorder;
    background: $errorBg;
    color: $errorFg;
  }
`;

const ModalSurface = styled.form("RodDevtoolsModalSurface").css`
  width: min(100%, var(--rd-modal-max-width, 480px));
  max-height: min(80vh, var(--rd-modal-max-height, 620px));
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: $background;
  border: 1px solid $border;
  border-radius: $modal;
  box-shadow: $shadow.modal;
`;

const ModalBox = styled.div("RodDevtoolsModalBox").css`
  width: min(100%, var(--rd-modal-max-width, 480px));
  max-height: min(80vh, var(--rd-modal-max-height, 620px));
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: $background;
  border: 1px solid $border;
  border-radius: $modal;
  box-shadow: $shadow.modal;
`;

const ModalTitle = styled.div("RodDevtoolsModalTitle").css`
  padding: 13px 14px;
  color: $primary;
  font-weight: 700;
  border-bottom: 1px solid $border;
`;

const ModalBody = styled.div("RodDevtoolsModalBody").css`
  padding: 14px;
  overflow: auto;
  color: $foreground;
  user-select: text;
`;

const ModalInput = styled.input("RodDevtoolsModalInput").css`
  width: 100%;
  min-width: 0;
  margin-top: 12px;
  padding: 9px 10px;
  border: 1px solid $border;
  border-radius: $control;
  outline: none;
  background: $backgroundDark;
  color: $primary;
  user-select: text;

  &:focus {
    border-color: $accent;
  }
`;

const ModalActions = styled.div("RodDevtoolsModalActions").css`
  padding: 10px;
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  border-top: 1px solid $border;
`;

const TextButton = styled.button("RodDevtoolsTextButton").css`
  flex: 0 0 auto;
  min-width: 74px;
  min-height: 28px;
  padding: 8px 11px;
  display: inline-grid;
  place-items: center;
  border: 0;
  border-radius: $control;
  background: $backgroundDark;
  color: $primary;
  cursor: pointer;
  font: inherit;
  font-size: 12px;
  transition: color .18s, background .18s, transform .1s;

  &:hover {
    background: $highlight;
    color: $selectedForeground;
  }

  &:active {
    transform: scale(.94);
    color: $accent;
  }

  &[data-primary="true"] {
    background: $accent;
    color: white;
  }
`;


const SHELL_STYLED_COMPONENTS = Object.freeze([
  ShellRoot,
  EntryButtonView,
  DevtoolsDock,
  Resizer,
  Tabbar,
  ToolPanel,
  TabButton,
  TabIcon,
  TabLabel,
  BuildBadge,
  Tools,
  Notifications,
  ModalRoot,
  NotificationToast,
  ModalSurface,
  ModalBox,
  ModalTitle,
  ModalBody,
  ModalInput,
  ModalActions,
  TextButton,
]);

export const shellStyleArtifacts: readonly CipoCssArtifact[] = Object.freeze(
  filterArray(flatMap(SHELL_STYLED_COMPONENTS, (styledComponent) => styledComponent.artifacts), (artifact): artifact is CipoCssArtifact => artifact.kind === "cipo.css"),
);

export type ShellRefs = DevtoolsShellRefs;

export interface ShellMount {
  readonly refs: ShellRefs;
  readonly dispose: () => void;
}

interface ShellViewProps {
  refs: Partial<ShellRefs>;
}

component<ShellViewProps>("RodDevtoolsShell", function RodDevtoolsShell(props, ctx) {
  const shared = ctx.requireContext(DevtoolsContext);
  const refs = props.refs;

  return html`
    <RodDevtoolsShellRoot
      :inline=${shared.inline}
      :roderudaRoot
      :roderudaShellRef="root"
      ref=${(node: HTMLElement) => {
        refs.root = node;
      }}
    >
      <RodDevtoolsEntryButton
        type="button"
        aria-label="Open developer tools"
        title="RodEruda"
        @click=${event.click((click) => {
          click.preventDefault();
          click.stopPropagation();
          shared.controller.peek()?.toggle();
        })}
        :roderudaShellRef="entryButton"
        ref=${(node: HTMLButtonElement) => {
          refs.entryButton = node;
        }}
      >
        ${icon("bug", {
           width: 24,
           height: 24,
        })}
      </RodDevtoolsEntryButton>

      <RodDevtoolsDock
        :inline=${shared.inline}
        :active=${shared.visible}
        aria-label="Developer tools"
        aria-hidden=${() => String(!shared.visible())}
        :roderudaShellRef="devtools"
        ref=${(node: HTMLElement) => {
          refs.devtools = node;
        }}
      >
        <RodDevtoolsResizer
          role="separator"
          aria-orientation="horizontal"
          aria-label="Resize developer tools"
          :roderudaShellRef="resizer"
          @pointerdown=${event.pointerdown((pointer) => shared.controller.peek()?.beginResize?.(pointer))}
          @pointermove=${event.pointermove((pointer) => shared.controller.peek()?.updateResize?.(pointer))}
          @pointerup=${event.pointerup((pointer) => shared.controller.peek()?.endResize?.(pointer))}
          @pointercancel=${event.pointercancel((pointer) => shared.controller.peek()?.endResize?.(pointer))}
          ref=${(node: HTMLElement) => {
            refs.resizer = node;
          }}
        />

        <RodDevtoolsTabbar
          aria-label="Developer tools panels"
          :roderudaShellRef="tabbar"
          ref=${(node: HTMLElement) => {
            refs.tabbar = node;
          }}
        >
          ${repeat(shared.tools, (entry) => entry.name, ({ item }) => html`
            <RodDevtoolsTabButton
              type="button"
              role="tab"
              :toolTab=${() => item().name}
              :selected=${() => shared.activePanel() === item().name}
              aria-selected=${() => String(shared.activePanel() === item().name)}
              hidden=${() => item().disabled}
              draggable=${() => item().name === "settings" ? "false" : "true"}
              @click=${event.click((click) => {
                click.preventDefault();
                item().activate();
              })}
              @dragstart=${event.dragstart((drag) => item().dragStart(drag))}
              @dragover=${event.dragover((drag) => item().dragOver(drag))}
              @drop=${event.drop((drop) => item().drop(drop))}
            >
              <RodDevtoolsTabIcon>${renderToolIcon(item().icon, item().name)}</RodDevtoolsTabIcon>
              <RodDevtoolsTabLabel>${() => item().title}</RodDevtoolsTabLabel>
            </RodDevtoolsTabButton>
          `)}
          <RodDevtoolsBuildBadge :roderudaBuildBadge title=${`Build ${DEVTOOLS_BUILD_INFO.sha} · ${DEVTOOLS_BUILD_INFO.builtAtGmtMinus3}`}>${DEVTOOLS_BUILD_BADGE}</RodDevtoolsBuildBadge>
        </RodDevtoolsTabbar>

        <RodDevtoolsTools
          :roderudaShellRef="tools"
          ref=${(node: HTMLElement) => {
            refs.tools = node;
          }}
        >
          ${repeat(shared.tools, (entry) => entry.name, ({ item }) => html`
            <RodDevtoolsToolPanel
              role="tabpanel"
              :tool=${() => item().name}
              aria-label=${() => item().title}
              hidden=${() => item().disabled || shared.activePanel() !== item().name}
              ref=${(node: HTMLElement) => item().mount(node)}
            >
              ${item().view()}
            </RodDevtoolsToolPanel>
          `)}
        </RodDevtoolsTools>

        <RodDevtoolsNotifications
          aria-live="polite"
          :roderudaShellRef="notifications"
          ref=${(node: HTMLElement) => {
            refs.notifications = node;
          }}
        >
          ${repeat(shared.notifications, (entry) => entry.id, ({ item }) => html`
            <RodDevtoolsNotificationToast
              role=${() => item().type === "error" ? "alert" : "status"}
              :type=${() => item().type}
              :active=${() => item().active()}
              :notification=${() => item().id}
              @click=${event.click((click) => {
                click.preventDefault();
                item().dismiss();
              })}
            >
              ${() => item().message}
            </RodDevtoolsNotificationToast>
          `)}
        </RodDevtoolsNotifications>

        <RodDevtoolsModalRoot
          role="presentation"
          :active=${() => shared.modal() != null}
          :roderudaShellRef="modalRoot"
          ref=${(node: HTMLElement) => {
            refs.modalRoot = node;
          }}
        >
          ${shared.modal}
        </RodDevtoolsModalRoot>
      </RodDevtoolsDock>
    </RodDevtoolsShellRoot>
  `;
});

/** Mounts the whole DevTools application under one Fábrica context provider. */
export function renderShell(
  target: HTMLElement | ShadowRoot,
  shared: DevtoolsContextValue,
): ShellMount {
  const refs = {} as Partial<ShellRefs>;

  debugLog("shell", "render:start", {
    inline: shared.inline,
    target: target instanceof ShadowRoot ? "shadow" : "element",
  });

  const dispose = renderInto(target, html`
    <${DevtoolsContext.Provider} props=${{ value: shared }}>
      <RodDevtoolsShell .refs=${refs} />
    </${DevtoolsContext.Provider}>
  `);

  const shellRefs = assertShellRefs(refs, target);
  shared.refs.set(shellRefs);

  debugLog("shell", "render:end", { refs: objectKeys(shellRefs) });

  return { refs: shellRefs, dispose };
}

function renderToolIcon(value: Node | string | undefined, name: string): Node | string {
  if (typeof value === "string") return value;
  if (value instanceof Node) return value.cloneNode(true);

  const fallback = icon(name);
  return fallback instanceof Node ? fallback.cloneNode(true) : name.slice(0, 1).toUpperCase();
}

function assertShellRefs(refs: Partial<ShellRefs>, target: HTMLElement | ShadowRoot): ShellRefs {
  const keys = [
    "root",
    "entryButton",
    "devtools",
    "resizer",
    "tabbar",
    "tools",
    "notifications",
    "modalRoot",
  ] as const;

  for (const key of keys) {
    if (refs[key]) continue;

    const node = target.querySelector(`[data-roderuda-shell-ref="${key}"]`);
    if (node) assignShellRef(refs, key, node);
  }

  const missing = filterArray(keys, (key) => !refs[key]);
  if (missing.length) {
    throw new Error(`[RodEruda] Shell did not mount: ${joinArray(missing, ", ")}`);
  }

  return refs as ShellRefs;
}

function assignShellRef(refs: Partial<ShellRefs>, key: keyof ShellRefs, node: Element): void {
  if (key === "entryButton") {
    refs.entryButton = node as HTMLButtonElement;
    return;
  }

  refs[key] = node as HTMLElement;
}
