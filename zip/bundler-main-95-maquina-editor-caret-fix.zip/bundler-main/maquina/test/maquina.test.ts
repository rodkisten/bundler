/** @vitest-environment jsdom */

import { beforeEach, describe, expect, it } from "vitest";
import { mountMaquina } from "@rodkisten/maquina/editor";
import { tokenizeMaquina } from "@rodkisten/maquina/tokenizer";

describe("Maquina", () => {
  beforeEach(() => {
    document.body.replaceChildren();
  });

  it("mounts, edits and destroys without external editor dependencies", () => {
    const parent = document.createElement("div");
    document.body.append(parent);
    const changes: string[] = [];
    const editor = mountMaquina({
      parent,
      value: "const x = 1",
      language: "javascript",
      onChange: (value) => changes.push(value),
    });

    expect(editor.getValue()).toBe("const x = 1");
    editor.setValue("const x = 2");
    expect(editor.getValue()).toBe("const x = 2");
    editor.destroy();
    expect(parent.childNodes).toHaveLength(0);
  });

  it("dispatches transactions and supports undo and redo", () => {
    const parent = document.createElement("div");
    document.body.append(parent);
    const editor = mountMaquina({ parent, value: "abc" });

    editor.dispatch({
      changes: [{ from: 1, to: 2, insert: "X" }],
      selection: { anchor: 2, head: 2 },
      origin: "api",
    });

    expect(editor.getValue()).toBe("aXc");
    expect(editor.getState().selection).toEqual({
      anchor: 2,
      head: 2,
    });
    expect(editor.undo()).toBe(true);
    expect(editor.getValue()).toBe("abc");
    expect(editor.redo()).toBe(true);
    expect(editor.getValue()).toBe("aXc");
  });

  it(
    "restores line numbers and updates them with the document",
    () => {
      const parent = document.createElement("div");
      document.body.append(parent);
      const editor = mountMaquina({
        parent,
        value: "one\ntwo\nthree",
      });

      expect(readLineNumbers(parent)).toEqual(["1", "2", "3"]);

      editor.setValue("one\ntwo\nthree\nfour");

      expect(readLineNumbers(parent)).toEqual(["1", "2", "3", "4"]);
    },
  );

  it("can explicitly disable the line-number gutter", () => {
    const parent = document.createElement("div");
    document.body.append(parent);
    mountMaquina({
      parent,
      value: "one\ntwo",
      lineNumbers: false,
    });

    const root = parent.firstElementChild as HTMLElement;

    expect(readLineNumbers(parent)).toEqual([]);
    expect(root.style.getPropertyValue("--maq-gutter-width")).toBe("0px");
  });

  it(
    "aligns textarea and highlight metrics without root scaling",
    () => {
      const parent = document.createElement("div");
      document.body.append(parent);
      mountMaquina({
        parent,
        value: "const x = 1",
        fontSize: 12,
      });

      const root = parent.firstElementChild as HTMLElement;
      const textarea = parent.querySelector("textarea")!;
      const highlight = parent.querySelector<HTMLElement>(
        "[aria-hidden='true']",
      )!;

      expect(root.style.transform).toBe("none");
      expect(root.style.width).toBe("100%");
      expect(root.style.height).toBe("100%");
      expect(textarea.style.fontSize).toBe(highlight.style.fontSize);
      expect(textarea.style.fontSize).toBe("12px");
    },
  );

  it("keeps the textarea sized to the editor container", () => {
    const parent = document.createElement("div");
    document.body.append(parent);
    mountMaquina({ parent, value: "x" });

    const textarea = parent.querySelector("textarea")!;
    const root = parent.firstElementChild as HTMLElement;

    expect(root.style.width).toBe("100%");
    expect(root.style.height).toBe("100%");
    expect(textarea.getAttribute("role")).toBe("combobox");
  });

  it("renders touch-friendly accessible scope completions", async () => {
    const parent = document.createElement("div");
    document.body.append(parent);
    const value = "const localThing = 1;\nloc";

    mountMaquina({
      parent,
      value,
      language: "javascript",
    });

    const textarea = parent.querySelector("textarea")!;

    textarea.setSelectionRange(value.length, value.length);
    textarea.dispatchEvent(new Event("input", { bubbles: true }));
    await Promise.resolve();

    const listbox = parent.querySelector<HTMLElement>("[role='listbox']")!;
    const options = Array.from(
      listbox.querySelectorAll<HTMLElement>("[role='option']"),
    );

    expect(textarea.getAttribute("aria-expanded")).toBe("true");
    expect(options.some((option) => {
      return option.textContent?.includes("localThing");
    })).toBe(true);
    expect(options.every((option) => option.tagName === "DIV")).toBe(true);
  });

  it(
    "provides object members declared in the current source scope",
    async () => {
      const parent = document.createElement("div");
      document.body.append(parent);
      const value = [
        "const machine = {",
        "  name: 'Máquina',",
        "  write(message) { return message; },",
        "};",
        "machine.w",
      ].join("\n");

      mountMaquina({
        parent,
        value,
        language: "javascript",
      });

      const textarea = parent.querySelector("textarea")!;

      textarea.setSelectionRange(value.length, value.length);
      textarea.dispatchEvent(new Event("input", { bubbles: true }));
      await Promise.resolve();

      const optionLabels = Array.from(
        parent.querySelectorAll<HTMLElement>("[role='option'] > span"),
      ).map((node) => node.textContent);

      expect(optionLabels).toContain("write");
    },
  );

  it("keeps the native textarea and highlighted projection byte-for-byte aligned", () => {
    const parent = document.createElement("div");
    document.body.append(parent);
    const source = [
      "const machine = {",
      "  name: 'Máquina',",
      "",
      "  run() { return true; }",
      "};",
    ].join("\n");

    mountMaquina({
      parent,
      value: source,
      language: "javascript",
    });

    const textarea = parent.querySelector("textarea")!;
    const highlighted = Array.from(
      parent.querySelectorAll<HTMLElement>("[data-maquina-line-code]"),
    ).map((line) => line.textContent ?? "").join("\n");

    expect(textarea.wrap).toBe("off");
    expect(highlighted).toBe(source);
  });

  it("does not open runtime completions when a tap only moves the caret", async () => {
    const parent = document.createElement("div");
    document.body.append(parent);

    mountMaquina({
      parent,
      value: "const machine = window;",
      language: "javascript",
    });

    const textarea = parent.querySelector("textarea")!;
    const listbox = parent.querySelector<HTMLElement>("[role='listbox']")!;

    textarea.setSelectionRange(6, 6);
    textarea.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    await Promise.resolve();

    expect(textarea.getAttribute("aria-expanded")).toBe("false");
    expect(listbox.hidden).toBe(true);
    expect(listbox.childElementCount).toBe(0);
  });

  it("renders token text without template whitespace or host span leakage", () => {
    const hostStyle = document.createElement("style");
    hostStyle.textContent = "span { display: block; margin: 20px; letter-spacing: 1em; }";
    document.head.append(hostStyle);

    const parent = document.createElement("div");
    document.body.append(parent);
    const source = "const machine = { name: 'Máquina' };";

    mountMaquina({
      parent,
      value: source,
      language: "javascript",
    });

    const code = parent.querySelector<HTMLElement>(
      "[data-maquina-line-code='1']",
    )!;
    const tokens = Array.from(
      code.querySelectorAll<HTMLElement>("[data-token]"),
    );

    expect(code.textContent).toBe(source);
    expect(tokens.length).toBeGreaterThan(1);
    expect(tokens.every((token) => token.textContent?.includes("\n") === false)).toBe(true);
    expect(tokens.every((token) => token.className.includes("MaquinaTokenText"))).toBe(true);

    hostStyle.remove();
  });

  it("tokenizes supported languages", () => {
    const javascriptTokens = tokenizeMaquina(
      "const x = 'a'",
      "javascript",
    );
    const htmlTokens = tokenizeMaquina(
      '<main id="x">',
      "html",
    );
    const cssTokens = tokenizeMaquina(
      ".x{color:red}",
      "css",
    );

    expect(
      javascriptTokens.some((token) => token.kind === "keyword"),
    ).toBe(true);
    expect(
      htmlTokens.some((token) => token.kind === "tag"),
    ).toBe(true);
    expect(
      cssTokens.some((token) => token.kind === "tag"),
    ).toBe(true);
  });

  it("provides a CodeMirror-compatible completion context shape", async () => {
    const parent = document.createElement("div");
    document.body.append(parent);
    let seen = "";

    mountMaquina({
      parent,
      value: "doc",
      activateCompletionOnTyping: true,
      completions(context) {
        seen = context.matchBefore(/[$\w.]+$/)?.text ?? "";

        return {
          from: 0,
          options: [{ label: "document" }],
        };
      },
    });

    const textarea = parent.querySelector("textarea")!;

    textarea.setSelectionRange(
      textarea.value.length,
      textarea.value.length,
    );
    textarea.dispatchEvent(new Event("input", { bubbles: true }));
    await Promise.resolve();

    expect(seen).toBe("doc");
  });
  it("isolates REPL keyboard events and uses modified Enter for newlines", () => {
    const parent = document.createElement("div");
    document.body.append(parent);
    let runs = 0;
    let bubbled = 0;
    const onBodyKeyDown = (): void => { bubbled += 1; };
    document.body.addEventListener("keydown", onBodyKeyDown);

    const editor = mountMaquina({
      parent,
      value: "const value = 1",
      isolateKeyboardEvents: true,
      modifiedEnter: "newline",
      onRun: () => { runs += 1; },
    });
    const textarea = parent.querySelector("textarea")!;
    textarea.setSelectionRange(textarea.value.length, textarea.value.length);

    textarea.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", shiftKey: true, bubbles: true, cancelable: true }));
    expect(editor.getValue()).toBe("const value = 1\n");
    expect(runs).toBe(0);
    expect(bubbled).toBe(0);

    textarea.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", ctrlKey: true, bubbles: true, cancelable: true }));
    expect(editor.getValue()).toBe("const value = 1\n\n");
    expect(runs).toBe(0);
    expect(bubbled).toBe(0);

    textarea.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true, cancelable: true }));
    expect(runs).toBe(1);
    expect(bubbled).toBe(0);
    document.body.removeEventListener("keydown", onBodyKeyDown);
  });

});

function readLineNumbers(parent: HTMLElement): string[] {
  return Array.from(
    parent.querySelectorAll<HTMLElement>("[data-maquina-line-number]"),
  ).map((node) => node.textContent ?? "");
}
