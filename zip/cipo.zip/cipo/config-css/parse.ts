import { CipoCompiledConfigOpcode, type CipoCompiledCssConfig } from '../compiled-config'
import type { CipoConfig, CipoPropertyDefinition, CipoTheme, CipoThemeValue, CipoTypedThemeOptions, CipoWarning } from '../types'
import { typedTheme } from '../theme-value'
import { stripCipoComments } from '../syntax/css-lexer'
import { findMatchingBrace, findTopLevelColon, splitTopLevel, toKebabMixed } from '../utils'
import type { Mutable, PreparedCssConfig, PreparedOperation } from './contracts'
import { mergeConfigPatch, mergeTheme } from './shared'

const CONFIG_PLAN_CACHE_LIMIT = 128
const preparedConfigCache = new Map<string, PreparedCssConfig>()

/** Returns a cached immutable parse plan for CSS-first configuration source. */
export function getPreparedCssConfig(source: string): PreparedCssConfig {
  const cached = preparedConfigCache.get(source)
  if (cached) return cached

  const prepared = deepFreeze(prepareCssConfig(source))
  preparedConfigCache.set(source, prepared)
  if (preparedConfigCache.size > CONFIG_PLAN_CACHE_LIMIT) {
    const oldest = preparedConfigCache.keys().next().value as string | undefined
    if (oldest !== undefined) preparedConfigCache.delete(oldest)
  }
  return prepared
}

/** Clears only the pure parse-plan cache. Runtime application caches live elsewhere. */
export function clearPreparedCssConfigCache(): void {
  preparedConfigCache.clear()
}

/**
 * Compiles readable CSS-first configuration into a serializable parser-free payload.
 *
 * @remarks
 * Presets and config plugins are intentionally left on the runtime parser path because
 * their behavior can depend on user-registered functions. Pure config/theme/alias/
 * property/layer sheets can be safely lowered for production.
 */
export function compileCssConfigPayload(input: string): CipoCompiledCssConfig | null {
  const prepared = getPreparedCssConfig(String(input || ''))
  const operations = [] as import('../compiled-config').CipoCompiledConfigOperation[]

  for (let index = 0; index < prepared.operations.length; index += 1) {
    const operation = prepared.operations[index]!
    if (operation.kind === 'preset' || operation.kind === 'plugin') return null
    if (operation.kind === 'config') operations.push([CipoCompiledConfigOpcode.Config, operation.patch])
    else if (operation.kind === 'theme') {
      operations.push([CipoCompiledConfigOpcode.Theme, operation.patch])
    } else if (operation.kind === 'theme-scope') {
      operations.push([
        CipoCompiledConfigOpcode.ThemeScope,
        operation.name,
        operation.extends ?? '',
        operation.patch,
      ])
    }
    else if (operation.kind === 'alias') operations.push([CipoCompiledConfigOpcode.Alias, operation.name, operation.cssText])
    else if (operation.kind === 'property') operations.push([CipoCompiledConfigOpcode.Property, operation.name, operation.definition])
    else if (operation.kind === 'layer') operations.push([CipoCompiledConfigOpcode.Css, operation.cssText])
  }

  return { operations }
}

function prepareCssConfig(rawSource: string): PreparedCssConfig {
  // Configuration directives are discovered only in lexical CSS code. Removing
  // comments up front prevents `@theme`/`@cipo` text in documentation comments
  // from becoming executable configuration while preserving strings and URLs.
  const source = stripCipoComments(rawSource)
  const operations: PreparedOperation[] = []
  const warnings: CipoWarning[] = []
  const appliedAliases: string[] = []
  const appliedProperties: string[] = []
  const appliedPresets: string[] = []
  const appliedPlugins: string[] = []
  const configPatch: Partial<Mutable<CipoConfig>> = {}
  let themePatch: CipoTheme = {}
  let index = 0

  while (index < source.length) {
    const at = findNextAt(source, index)
    if (at < 0) break
    const nameStart = at + 1
    const nameEnd = readIdentifierEnd(source, nameStart)
    const directive = source.slice(nameStart, nameEnd)
    const cursor = skipSpaces(source, nameEnd)
    const namedBlock = readNamedBlock(source, cursor)
    const functionalBlock = readFunctionalBlock(source, cursor)
    const directiveBlock = functionalBlock ?? namedBlock

    if (source[cursor] === '{' || directiveBlock) {
      const open = directiveBlock ? directiveBlock.open : cursor
      const close = findMatchingBrace(source, open)
      if (close < 0) {
        warnings.push(createWarning('cipo-config-unclosed-block', `Unclosed @${directive} block.`))
        break
      }

      const body = source.slice(open + 1, close)

      if (directive === 'cipo' || directive === 'config') {
        const patch = parseCipoBlock(body)
        mergeConfigPatch(configPatch, patch)
        operations.push({ kind: 'config', patch })
      } else if (directive === 'theme' || directive === 'tokens') {
        const patch = parseThemeBlock(body)
        const scope = functionalBlock
          ? parseThemeScopeHeader(functionalBlock.name)
          : null
        if (scope) {
          operations.push({
            kind: 'theme-scope',
            name: scope.name,
            ...(scope.extends ? { extends: scope.extends } : {}),
            patch,
          })
        } else {
          themePatch = mergeTheme(themePatch, patch)
          operations.push({ kind: 'theme', patch })
        }
      } else if (directive === 'breakpoints') {
        const patch: Partial<Mutable<CipoConfig>> = { breakpoints: parseBreakpointsBlock(body) }
        mergeConfigPatch(configPatch, patch)
        operations.push({ kind: 'config', patch })
      } else if (directive === 'alias' || directive === 'helper') {
        const aliasName = directiveBlock?.name || ''
        if (aliasName) {
          operations.push({ kind: 'alias', name: aliasName, cssText: body.trim() })
          appliedAliases.push(aliasName)
        } else {
          warnings.push(createWarning('cipo-config-alias-name-missing', `@${directive} needs a name.`))
        }
      } else if (directive === 'property') {
        const rawName = directiveBlock?.name || ''
        if (rawName) {
          operations.push({ kind: 'property', name: rawName, definition: parsePropertyDefinition(body) })
          appliedProperties.push(rawName)
        } else {
          warnings.push(createWarning('cipo-config-property-name-missing', '@property needs a custom property name.'))
        }
      } else {
        warnings.push(createWarning('cipo-config-unknown-directive', `Unknown CSS-first directive: @${directive}`))
      }

      index = close + 1
      continue
    }

    const statementEnd = findStatementEnd(source, cursor)
    const args = source.slice(cursor, statementEnd).trim().replace(/;$/, '').trim()

    if (directive === 'preset') {
      operations.push({ kind: 'preset', name: args })
      if (args) appliedPresets.push(args)
    } else if (directive === 'plugin') {
      operations.push({ kind: 'plugin', name: args })
      if (args) appliedPlugins.push(args)
    } else if (directive === 'layer') {
      const cssText = normalizeLayerStatement(args)
      if (cssText) operations.push({ kind: 'layer', cssText })
    } else {
      warnings.push(
        createWarning(
          'cipo-config-unknown-directive',
          `Unknown CSS-first directive: @${directive}`,
        ),
      )
    }

    index = statementEnd + 1
  }

  return {
    source: rawSource,
    operations,
    config: configPatch,
    theme: themePatch,
    warnings,
    appliedAliases,
    appliedProperties,
    appliedPresets,
    appliedPlugins,
  }
}

function deepFreeze<T>(value: T): T {
  if (!value || typeof value !== 'object' || Object.isFrozen(value)) return value

  for (const key of Reflect.ownKeys(value as object)) {
    const child = (value as Record<PropertyKey, unknown>)[key]
    deepFreeze(child)
  }

  return Object.freeze(value)
}

function createWarning(code: string, message: string): CipoWarning {
  return { code, message }
}


function parseCipoBlock(body: string): Partial<Mutable<CipoConfig>> {
  const entries = parseFlatDeclarationMap(body)
  const config: Partial<Mutable<CipoConfig>> = {}

  for (const key in entries) {
    const value = entries[key]!
    if (key === 'prefix') config.prefix = stripQuotes(value)
    else if (key === 'layers') config.layers = parseBoolean(value)
    else if (key === 'important') config.important = parseBoolean(value)
    else if (key === 'debug') config.debug = parseBoolean(value)
    else if (key === 'minify') config.minify = parseBoolean(value)
    else if (key === 'atomic-min-uses' || key === 'atomicMinUses') config.atomic = { minUses: parseCssNumber(value, 1) }
    else if (key === 'scope') config.scope = stripQuotes(value)
    else if (key === 'scope-selector' || key === 'scopeSelector') config.scope = { ...(typeof config.scope === 'object' ? config.scope : {}), selector: stripQuotes(value) }
    else if (key === 'scope-strategy' || key === 'scopeStrategy') config.scope = { ...(typeof config.scope === 'object' ? config.scope : {}), strategy: stripQuotes(value) as never }
    else if (key === 'debug-overlay' || key === 'debugOverlay') config.debugOverlay = parseBoolean(value)
    else if (key === 'color-mode' || key === 'colorMode') config.colorMode = stripQuotes(value) as NonNullable<CipoConfig['colorMode']>
    else if (key === 'dark-selector' || key === 'darkSelector') config.darkSelector = stripQuotes(value)
    else if (key === 'theme-root' || key === 'themeRoot' || key === 'themeRootSelector') config.themeRootSelector = stripQuotes(value)
    else if (key === 'theme-validation' || key === 'themeValidation') {
      const mode = stripQuotes(value)
      if (mode === 'strict' || mode === 'warn' || mode === 'off') config.themeValidation = mode
    }
    else if (key === 'register-typed-theme-properties' || key === 'registerTypedThemeProperties') {
      config.registerTypedThemeProperties = parseBoolean(value)
    }
    else if (key === 'rem') config.rem = { enabled: true, baseFontSize: parseCssNumber(value, 16) }
    else if (key === 'base-font-size' || key === 'baseFontSize') config.baseFontSize = parseCssNumber(value, 16)
  }

  return config
}

function parseThemeBlock(body: string): CipoTheme {
  const entries = parseObjectEntries(body)
  return objectEntriesToTheme(entries)
}

function objectEntriesToTheme(entries: readonly ObjectEntry[]): CipoTheme {
  const output: Record<string, CipoThemeValue> = Object.create(null)
  for (let index = 0; index < entries.length; index += 1) {
    const entry = entries[index]!
    const value = Array.isArray(entry.value)
      ? objectEntriesToTheme(entry.value)
      : stripTrailingSemicolon(entry.value)
    output[entry.key] = entry.type
      ? typedTheme(entry.type, value, entry.options)
      : value
  }
  return output
}

function parseBreakpointsBlock(body: string): Record<string, string | null> {
  const entries = parseFlatDeclarationMap(body)
  const output: Record<string, string | null> = Object.create(null)
  for (const key in entries) output[key] = normalizeBreakpoint(entries[key]!)
  return output
}

function parsePropertyDefinition(body: string): CipoPropertyDefinition {
  const entries = parseFlatDeclarationMap(body)
  return {
    syntax: stripQuotes(entries.syntax || '*'),
    inherits: entries.inherits === undefined ? true : parseBoolean(entries.inherits),
    initialValue: entries.initialValue ?? entries.initial ?? '',
  }
}

function parseFlatDeclarationMap(body: string): Record<string, string> {
  const output: Record<string, string> = Object.create(null)
  const parts = splitTopLevelStatements(body)
  for (let index = 0; index < parts.length; index += 1) {
    const part = parts[index]!.trim()
    if (!part) continue
    const colon = findTopLevelColon(part)
    if (colon <= 0) continue
    const key = toCamelSafe(part.slice(0, colon).trim().replace(/^[$]+/, ''))
    output[key] = stripTrailingSemicolon(part.slice(colon + 1).trim())
  }
  return output
}

type ObjectEntry = {
  key: string
  value: string | ObjectEntry[]
  type?: string
  options?: CipoTypedThemeOptions
}

function parseObjectEntries(body: string): ObjectEntry[] {
  const parts = splitTopLevelStatements(body)
  const output: ObjectEntry[] = []
  for (let index = 0; index < parts.length; index += 1) {
    const part = parts[index]!.trim()
    if (!part) continue
    const colon = findThemeEntryColon(part)
    if (colon <= 0) continue
    const annotation = parseTypedThemeKey(part.slice(0, colon).trim().replace(/^[$]+/, ''))
    let value = stripTrailingSemicolon(part.slice(colon + 1).trim())
    const entry: ObjectEntry = value.startsWith('(') && value.endsWith(')')
      ? { ...annotation, value: parseObjectEntries(value.slice(1, -1)) }
      : { ...annotation, value }
    output.push(entry)
  }
  return output
}

function findThemeEntryColon(input: string): number {
  let structuralDepth = 0
  let annotationDepth = 0
  let quote: '"' | "'" | null = null

  for (let index = 0; index < input.length; index += 1) {
    const char = input[index]!
    if (quote) {
      if (char === quote && input[index - 1] !== '\\') quote = null
      continue
    }
    if (char === '"' || char === "'") {
      quote = char
      continue
    }
    if (char === '(' || char === '[') { structuralDepth += 1; continue }
    if (char === ')' || char === ']') { structuralDepth = Math.max(0, structuralDepth - 1); continue }
    if (structuralDepth === 0 && char === '<') { annotationDepth += 1; continue }
    if (structuralDepth === 0 && char === '>') { annotationDepth = Math.max(0, annotationDepth - 1); continue }
    if (char === ':' && structuralDepth === 0 && annotationDepth === 0) return index
  }

  return -1
}

function parseTypedThemeKey(source: string): Pick<ObjectEntry, 'key' | 'type' | 'options'> {
  const text = source.trim()
  const open = text.lastIndexOf('<')
  if (open <= 0 || !text.endsWith('>')) return { key: toCamelSafe(text) }

  const rawName = text.slice(0, open).trim()
  const annotation = text.slice(open + 1, -1).trim()
  const parts = splitTopLevel(annotation, ',')
  const type = stripQuotes(parts.shift() || '').trim()
  if (!rawName || !type) return { key: toCamelSafe(text) }

  const options: Mutable<CipoTypedThemeOptions> = {}
  for (let index = 0; index < parts.length; index += 1) {
    const part = (parts[index] || '').trim()
    if (!part) continue
    if (part === 'register') options.register = true
    else if (part === 'no-register' || part === 'noregister') options.register = false
    else if (part === 'auto') options.register = 'auto'
    else {
      const colon = findTopLevelColon(part)
      if (colon <= 0) continue
      const name = toKebabMixed(part.slice(0, colon).trim())
      const value = stripQuotes(part.slice(colon + 1).trim())
      if (name === 'inherits') options.inherits = parseBoolean(value)
      else if (name === 'initial' || name === 'initial-value') options.initialValue = value
      else if (name === 'validation' && (value === 'strict' || value === 'warn' || value === 'off')) {
        options.validation = value
      }
    }
  }

  return {
    key: toCamelSafe(rawName),
    type,
    options,
  }
}

function splitTopLevelStatements(input: string): string[] {
  const output: string[] = []
  let buffer = ''
  let structuralDepth = 0
  let annotationDepth = 0
  let quote: '"' | "'" | null = null

  for (let index = 0; index < input.length; index += 1) {
    const char = input[index]!

    if (quote) {
      buffer += char
      if (char === quote && input[index - 1] !== '\\') quote = null
      continue
    }

    if (char === '"' || char === "'") {
      quote = char
      buffer += char
      continue
    }

    if (char === '(' || char === '[') structuralDepth += 1
    else if (char === ')' || char === ']') structuralDepth = Math.max(0, structuralDepth - 1)
    else if (char === '<' && structuralDepth === 0) annotationDepth += 1
    else if (char === '>' && structuralDepth === 0) annotationDepth = Math.max(0, annotationDepth - 1)

    const isHardSeparator = char === ';' || char === '\n' || char === '\r'
    const isMapEntryComma = char === ',' && startsObjectEntryAfter(input, index + 1)
    if ((isHardSeparator || isMapEntryComma) && structuralDepth === 0 && annotationDepth === 0) {
      if (buffer.trim()) output.push(buffer.trim())
      buffer = ''
      continue
    }

    buffer += char
  }

  if (buffer.trim()) output.push(buffer.trim())
  return output
}

/**
 * Distinguishes a map separator from a comma that belongs to a CSS value.
 *
 * `md: 14px, lg: 22px` splits, while font stacks, transition lists and other
 * comma-separated CSS values stay intact until a following `name:` entry.
 */
function startsObjectEntryAfter(input: string, start: number): boolean {
  let index = start
  while (index < input.length && /\s/.test(input[index] ?? '')) index += 1
  const candidateStart = index
  let annotationDepth = 0
  let quote: '"' | "'" | null = null

  for (; index < input.length; index += 1) {
    const char = input[index]!
    if (quote) {
      if (char === quote && input[index - 1] !== '\\') quote = null
      continue
    }
    if (char === '"' || char === "'") {
      quote = char
      continue
    }
    if (char === '<') { annotationDepth += 1; continue }
    if (char === '>') { annotationDepth = Math.max(0, annotationDepth - 1); continue }
    if (annotationDepth > 0) continue

    if (char === ':') {
      const candidate = input.slice(candidateStart, index).trim().replace(/^[$]+/, '')
      return /^[a-zA-Z0-9_][a-zA-Z0-9_.-]*(?:<[^>]+>)?$/.test(candidate)
    }
    if (char === ',' || char === ';' || char === '\n' || char === '\r' || char === ')') {
      return false
    }
  }

  return false
}

function readFunctionalBlock(
  input: string,
  start: number,
): { readonly name: string; readonly open: number } | null {
  if (input[start] !== '(') return null
  let quote: string | null = null
  let depth = 1

  for (let index = start + 1; index < input.length; index += 1) {
    const char = input[index] ?? ''
    if (quote) {
      if (char === quote && input[index - 1] !== '\\') quote = null
      continue
    }
    if (char === '"' || char === "'") {
      quote = char
      continue
    }
    if (char === '(') depth += 1
    else if (char === ')') {
      depth -= 1
      if (depth === 0) {
        const open = skipSpaces(input, index + 1)
        if (input[open] !== '{') return null
        return {
          name: input.slice(start + 1, index).trim(),
          open,
        }
      }
    }
  }

  return null
}

function parseThemeScopeHeader(
  input: string,
): { readonly name: string; readonly extends?: string } | null {
  const match = [
    '^',
    '([a-zA-Z][\\w-]*)',
    '(?:\\s+extends\\s+([a-zA-Z][\\w-]*))?',
    '$',
  ].join('')
  const result = new RegExp(match).exec(input.trim())
  if (!result?.[1]) return null
  return {
    name: result[1],
    ...(result[2] ? { extends: result[2] } : {}),
  }
}

function readNamedBlock(input: string, start: number): { readonly name: string; readonly open: number } | null {
  const name = readWordAfter(input, start)
  if (!name) return null
  const open = skipSpaces(input, start + name.length)
  return input[open] === '{' ? { name, open } : null
}

function normalizeBreakpoint(value: string): string | null {
  const text = stripQuotes(value).trim()
  if (!text || text === 'null' || text === 'none' || text === 'base') return null
  if (text.startsWith('(')) return text
  return `(min-width: ${text})`
}

function normalizeLayerStatement(args: string): string {
  const text = String(args || '').trim()
  if (!text) return ''
  return `@layer ${text};`
}

function findNextAt(input: string, start: number): number {
  let quote: '"' | "'" | null = null
  for (let index = start; index < input.length; index += 1) {
    const char = input[index]
    if (quote) {
      if (char === quote && input[index - 1] !== '\\') quote = null
      continue
    }
    if (char === '"' || char === "'") { quote = char; continue }
    if (char === '@') return index
  }
  return -1
}

function findStatementEnd(input: string, start: number): number {
  let quote: '"' | "'" | null = null
  for (let index = start; index < input.length; index += 1) {
    const char = input[index]
    if (quote) {
      if (char === quote && input[index - 1] !== '\\') quote = null
      continue
    }
    if (char === '"' || char === "'") { quote = char; continue }
    if (char === ';' || char === '\n' || char === '\r') return index
  }
  return input.length
}

function readWordAfter(input: string, start: number): string {
  let cursor = skipSpaces(input, start)
  const wordStart = cursor
  while (cursor < input.length && /[^\s{;]+/.test(input[cursor] || '')) cursor += 1
  return input.slice(wordStart, cursor).trim()
}

function readIdentifierEnd(input: string, start: number): number {
  let index = start
  while (index < input.length && /[a-zA-Z0-9_-]/.test(input[index] || '')) index += 1
  return index
}

function skipSpaces(input: string, start: number): number {
  let index = start
  while (index < input.length && /\s/.test(input[index] || '')) index += 1
  return index
}

function parseBoolean(value: string): boolean {
  const text = stripQuotes(value).trim().toLowerCase()
  return !(text === 'false' || text === '0' || text === 'no' || text === 'off')
}

function parseCssNumber(value: string, fallback: number): number {
  const match = /-?\d*\.?\d+/.exec(value)
  return match ? Number(match[0]) : fallback
}

function stripQuotes(value: string): string {
  const text = stripTrailingSemicolon(value).trim()
  if ((text.startsWith('"') && text.endsWith('"')) || (text.startsWith("'") && text.endsWith("'"))) return text.slice(1, -1)
  return text
}

function stripTrailingSemicolon(value: string): string {
  return String(value || '').trim().replace(/;+$/, '').trim()
}

function toCamelSafe(value: string): string {
  const text = value.trim()
  if (!text.includes('-')) return text
  return toKebabMixed(text).replace(/-([a-z0-9])/g, (_match, char: string) => char.toUpperCase())
}
