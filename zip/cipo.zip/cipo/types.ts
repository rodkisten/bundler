/**
 * Shared public and internal types used by every Cipó module.
 *
 * @remarks
 * This file is intentionally dependency-free so the runtime can be bundled as a
 * tiny browser-first package or copied into a userscript without dragging a graph
 * of side effects behind it.
 *
 * @example
 * ```ts
 * import type { CipoConfig, CipoCssArtifact } from './types'
 *
 * const config: CipoConfig = { prefix: 'rod' }
 * const className = String({ className: 'rod-a-x' } as CipoCssArtifact)
 * ```
 */
export type CipoPrimitive = string | number | boolean | null | undefined;

export type CipoAdapterName = "dom" | "solid" | "react" | "preact";
export type CipoColorMode = "oklch" | "oklab" | "hsl" | "rgba" | "preserve";
export type CipoLayerName =
  | "reset"
  | "tokens"
  | "base"
  | "atomic"
  | "scoped"
  | "global"
  | "inline"
  | "components"
  | "utilities"
  | "overrides";
export type AliasScale =
  | "spacing"
  | "radius"
  | "shadow"
  | "text"
  | "color"
  | "none";
export type CipoThemeValidationMode = "strict" | "warn" | "off";
export type CipoThemePropertyRegistration = "auto" | boolean;
export type CipoThemeValidationStatus = "valid" | "invalid" | "deferred";

export interface CipoTypedThemeOptions {
  readonly register?: CipoThemePropertyRegistration;
  readonly inherits?: boolean;
  readonly initialValue?: string | number;
  readonly validation?: CipoThemeValidationMode;
}

export interface CipoTypedThemeValue {
  readonly kind: "cipo.theme.typed";
  readonly type: string;
  readonly value: string | number | CipoTheme;
  readonly register: CipoThemePropertyRegistration;
  readonly inherits?: boolean;
  readonly initialValue?: string | number;
  readonly validation?: CipoThemeValidationMode;
}

export type CipoThemeValue =
  | string
  | number
  | CipoTheme
  | CipoTypedValue
  | CipoTypedThemeValue;

export interface CipoTheme {
  readonly [key: string]: CipoThemeValue;
}

export interface CipoThemeValidationResult {
  readonly status: CipoThemeValidationStatus;
  readonly valid: boolean;
  readonly type: string;
  readonly value: string;
  readonly reason?: string;
  readonly code?: string;
}

export interface CipoThemeTypeValidationContext {
  readonly path: string;
  readonly type: string;
  readonly definition: CipoThemeTypeDefinition;
}

export interface CipoThemeTypeDefinition {
  readonly name?: string;
  readonly cssSyntax?: string;
  readonly registrable?: boolean;
  readonly initialValue?: string | number;
  readonly inherits?: boolean;
  readonly validate?: (
    value: string,
    context: CipoThemeTypeValidationContext,
  ) => CipoThemeValidationResult;
}
export type CipoRecord = Record<string, unknown>;

export interface CipoTypedPropertyOptions {
  readonly inherits?: boolean;
}

export interface CipoPropertyDefinition {
  readonly syntax: string;
  readonly inherits?: boolean;
  readonly initial?: string | number;
  readonly initialValue?: string | number;
}

export type CipoPropertyMap = Record<string, CipoPropertyDefinition>;

export interface CipoTypedValue {
  readonly kind: "cipo.typed";
  readonly syntax: string;
  readonly inherits: boolean;
  readonly initialValue: string;
}

export interface CipoTypedFactory {
  (
    syntax: string,
    initialValue: string | number,
    inherits?: boolean,
  ): CipoTypedValue;
  angle(initialValue?: string | number, inherits?: boolean): CipoTypedValue;
  number(initialValue?: string | number, inherits?: boolean): CipoTypedValue;
  length(initialValue?: string | number, inherits?: boolean): CipoTypedValue;
  percent(initialValue?: string | number, inherits?: boolean): CipoTypedValue;
  percentage(
    initialValue?: string | number,
    inherits?: boolean,
  ): CipoTypedValue;
  color(initialValue?: string | number, inherits?: boolean): CipoTypedValue;
  time(initialValue?: string | number, inherits?: boolean): CipoTypedValue;
  integer(initialValue?: string | number, inherits?: boolean): CipoTypedValue;
  transform(initialValue?: string | number, inherits?: boolean): CipoTypedValue;
  shadow(initialValue?: string | number, inherits?: boolean): CipoTypedValue;
  image(initialValue?: string | number, inherits?: boolean): CipoTypedValue;
  string(initialValue?: string | number, inherits?: boolean): CipoTypedValue;
}

export interface CipoRemConfig {
  readonly enabled?: boolean;
  readonly baseFontSize?: number;
}

export interface CipoJitConfig {
  readonly enabled?: boolean;
  readonly cache?: boolean;
  readonly maxEntries?: number;
  readonly debug?: boolean;
}

/** Controls when declarations are emitted as shared atomic classes. */
export interface CipoAtomicPromotionConfig {
  /** Minimum global use count before an atomic class is emitted. Use 1 for classic always-atomic mode. */
  readonly minUses?: number;
}

/** Optional selector scope applied around generated atomic/scoped selectors. */
export interface CipoScopeConfig {
  readonly strategy?: "none" | "where" | "class" | "id" | "selector" | "host";
  readonly selector?: string;
}

/** Runtime debug overlay options for inspecting generated atoms on-page. */
export interface CipoDebugOverlayConfig {
  readonly enabled?: boolean;
  readonly target?: Document | ShadowRoot | HTMLElement | undefined;
  readonly position?: "left" | "right" | "bottom";
}

/**
 * Developer-facing debug configuration.
 *
 * @remarks
 * `debug: true` remains fully backwards-compatible and enables readable atomic
 * class names by default. A structured object allows production tooling to keep
 * debug diagnostics enabled while independently controlling class-name verbosity.
 */
export interface CipoDebugConfig {
  readonly enabled?: boolean;
  readonly readableClassNames?: boolean;
  readonly maxClassLabelLength?: number;
  readonly includeContext?: boolean;
}

export interface CipoOutputConfig {
  readonly minify?: boolean;
  readonly layers?: boolean;
  readonly pretty?: boolean;
}

export interface CipoConfig {
  readonly prefix?: string;
  readonly debug?: boolean | CipoDebugConfig;
  readonly important?: boolean;
  readonly adapter?: CipoAdapterName | CipoAdapter;
  readonly darkSelector?: string;
  readonly themeRootSelector?: string;
  readonly breakpoints?: Readonly<Record<string, string | null>>;
  readonly minify?: boolean;
  readonly layers?: boolean;
  readonly output?: CipoOutputConfig;
  readonly rem?: boolean | CipoRemConfig;
  readonly baseFontSize?: number;
  readonly colorMode?: CipoColorMode;
  readonly theme?: CipoTheme;
  readonly themeValidation?: CipoThemeValidationMode;
  readonly registerTypedThemeProperties?: boolean;
  readonly jit?: boolean | CipoJitConfig;
  readonly atomic?: boolean | CipoAtomicPromotionConfig;
  readonly scope?: string | CipoScopeConfig;
  readonly debugOverlay?: boolean | CipoDebugOverlayConfig;
  readonly onWarning?: ((warning: CipoWarning) => void) | undefined;
}

export interface CipoWarning {
  readonly code: string;
  readonly message: string;
  readonly context?: unknown;
  // TODO: implement source (emitter.ts is using it)
  readonly source?: unknown;
}

export interface CipoStyleObject {
  readonly [property: string]:
    | string
    | number
    | CipoStyleObject
    | null
    | undefined;
}

export type CipoCssInterpolation =
  | CipoPrimitive
  | CipoCssArtifact
  | CipoStylesheetArtifact
  | CipoInlineCssArtifact
  | CipoStyleObject;

export interface CipoDeclarationNode {
  readonly type: "declaration";
  readonly property: string;
  readonly value: string;
  readonly source: string;
}

export interface CipoBlockNode {
  readonly type: "block";
  readonly name: string;
  readonly body: readonly CipoAstNode[];
  readonly source: string;
}

export interface CipoDirectiveNode {
  readonly type: "directive";
  readonly name: string;
  readonly args: readonly string[];
  readonly source: string;
}

export type CipoAstNode =
  | CipoDeclarationNode
  | CipoBlockNode
  | CipoDirectiveNode;

export interface CipoRuleContext {
  readonly breakpoint?: string;
  readonly mediaQuery?: string;
  readonly notBreakpoint?: string;
  readonly pseudo?: string;
  readonly selector?: string;
  readonly dark?: boolean;
  readonly supports?: string;
  readonly container?: string;
  readonly layer?: CipoLayerName | string;
  readonly startingStyle?: boolean;
}

export interface CipoAtomicRule {
  readonly id: string;
  readonly className: string;
  readonly property: string;
  readonly value: string;
  readonly context: CipoRuleContext;
  readonly source: string;
}

export interface CipoScopedRule {
  readonly selector: string;
  readonly declarations: readonly CipoDeclarationNode[];
  readonly context: CipoRuleContext;
}

export interface CipoDebugArtifact {
  readonly id: string;
  readonly ast: readonly CipoAstNode[];
  readonly atoms: readonly CipoAtomicRule[];
  readonly scopedRules: readonly CipoScopedRule[];
  readonly warnings: readonly CipoWarning[];
}

export interface CipoCssArtifact {
  readonly kind: "cipo.css";
  readonly className: string;
  readonly scopeClassName: string;
  readonly atoms: readonly CipoAtomicRule[];
  readonly scopedRules: readonly CipoScopedRule[];
  readonly rawCss: string;
  readonly transformedCss: string;
  readonly compiledCss: string;
  readonly debug: CipoDebugArtifact;
  toString(): string;
  [Symbol.toPrimitive](): string;
  readonly [Symbol.toStringTag]: string;
}

/**
 * Full stylesheet artifact returned when css`` receives top-level stylesheet
 * selectors such as `.card { ... }`, `#app { ... }`, `:root { ... }`, or
 * stylesheet at-rules.
 *
 * @remarks
 * Unlike `CipoCssArtifact`, this artifact does not represent a class list. Its
 * string value is the transformed stylesheet text, which makes it useful for
 * `injectGlobal()`, `injectStyle()` and `<style>` tags.
 *
 * @example
 * ```ts
 * const sheet = css`
 *   .card { px: 4; }
 * `
 *
 * String(sheet)
 * // '.card { padding-inline: ... }'
 * ```
 */
export interface CipoStylesheetTextArtifact {
  readonly kind: "cipo.stylesheet";
  readonly cssText: string;
}

export interface CipoStylesheetArtifact extends CipoStylesheetTextArtifact {
  readonly kind: "cipo.stylesheet";
  readonly rawCss: string;
  readonly transformedCss: string;
  readonly debug: {
    readonly id: string;
    readonly ast: readonly CipoAstNode[];
    readonly warnings: readonly CipoWarning[];
    readonly mode: "stylesheet";
  };
  toString(): string;
  [Symbol.toPrimitive](): string;
  readonly [Symbol.toStringTag]: string;
}

/**
 * Polymorphic result returned by css``.
 *
 * @remarks
 * Component/declaration mode returns `CipoCssArtifact`. Stylesheet mode returns
 * `CipoStylesheetArtifact`. Callers that need a class list should narrow with
 * `isAtomicCssArtifact()` from `css.ts` or use `assertAtomicCssArtifact()`.
 */
export interface CipoCssConfigResult {
  readonly kind?: never;
  readonly config: Partial<CipoConfig>;
  readonly theme: CipoTheme;
  readonly warnings: readonly CipoWarning[];
  readonly appliedAliases: readonly string[];
  readonly appliedProperties: readonly string[];
  readonly appliedPresets: readonly string[];
  readonly appliedPlugins: readonly string[];
}

export type CipoCssResult =
  | CipoCssArtifact
  | CipoStylesheetArtifact
  | CipoInlineCssArtifact
  | CipoCssConfigResult;

export interface CipoInlineCssArtifact {
  readonly kind: "cipo.inline-css";
  readonly rawCss: string;
  readonly transformedCss: string;
  readonly cssText: string;
  toString(): string;
  [Symbol.toPrimitive](): string;
  readonly [Symbol.toStringTag]: string;
}

export type CipoInjectableStyleArtifact =
  | CipoCssArtifact
  | CipoInlineCssArtifact
  | CipoStylesheetArtifact
  | CipoStylesheetTextArtifact;

export interface CipoExplainResult {
  readonly found: boolean;
  readonly className: string;
  readonly atom?: CipoAtomicRule;
  readonly css?: string;
}

export interface CipoValidationIssue {
  readonly code: string;
  readonly message: string;
  readonly index: number;
}

export interface CipoValidationResult {
  readonly valid: boolean;
  readonly issues: readonly CipoValidationIssue[];
}

export interface CipoAdapter {
  readonly name?: string;
  readonly classProp: "class" | "className";
  mergeProps(
    props: CipoRecord | null | undefined,
    className: string,
  ): CipoRecord;
  createElement?(
    tag: string,
    props: CipoRecord | null | undefined,
    className: string,
  ): unknown;
  wrapComponent?(component: unknown, className: string): CipoComponent;
}

export type CipoComponent<Props extends CipoRecord = CipoRecord> = (
  props: Props,
) => unknown;

export type CipoTarget =
  | Element
  | string
  | CipoComponent
  | ((...args: never[]) => unknown);

export type CipoStyledInput<Props extends CipoRecord = CipoRecord> =
  | CipoCssResult
  | string
  | false
  | null
  | undefined
  | readonly CipoStyledInput<Props>[]
  | ((props: Props) => CipoStyledInput<Props>);

export interface CipoStyledBuilder<Props extends CipoRecord = CipoRecord, Result = unknown> {
  (
    strings: TemplateStringsArray,
    ...values: readonly CipoCssInterpolation[]
  ): Result;
  (input: CipoStyledInput<Props>): Result;
  css(
    strings: TemplateStringsArray,
    ...values: readonly CipoCssInterpolation[]
  ): Result;
}

export interface CipoStyledTagFactory {
  (
    strings: TemplateStringsArray,
    ...values: readonly CipoCssInterpolation[]
  ): CipoComponent;
  (input: Exclude<CipoStyledInput, string>): CipoComponent;
  css(
    strings: TemplateStringsArray,
    ...values: readonly CipoCssInterpolation[]
  ): CipoComponent;
  attrs(defaultProps: CipoRecord): CipoStyledTagFactory;
}

export interface CipoDomStyledResult<ElementType extends Element = Element> {
  readonly element: ElementType;
  readonly artifact: CipoCssResult | readonly CipoCssResult[] | undefined;
  readonly artifacts: readonly CipoCssResult[];
  readonly className: string;
}

export type CipoHelper = (args: string, context: CipoHelperContext) => string;
export type CipoAliasValue =
  | string
  | CipoStyleObject
  | (() => string | CipoStyleObject);

export interface CipoHelperContext {
  readonly name: string;
  readonly raw: string;
  readonly config: RuntimeConfig;
  resolveValue(value: string, property?: string): string;
}

export interface PropertyAliasDefinition {
  readonly property: string;
  readonly scale?: AliasScale;
}

export interface CipoRecipeDefinition {
  readonly base?: string | CipoStyleObject;
  readonly variants?: Record<string, Record<string, string | CipoStyleObject>>;
  readonly defaults?: Record<string, string>;
}

export interface CipoRecipe {
  (
    options?: Record<string, string | boolean | null | undefined>,
  ): CipoCssArtifact;
  readonly definition: CipoRecipeDefinition;
}

export interface CipoInjectStyleOptions {
  readonly nonce?: string;
  readonly dedupe?: boolean;
  readonly position?: "append" | "prepend";
}

export interface RuntimeConfig {
  prefix: string;
  debug: boolean;
  debugOptions: Required<CipoDebugConfig>;
  important: boolean;
  adapter: CipoAdapterName | CipoAdapter;
  darkSelector: string;
  themeRootSelector: string;
  breakpoints: Readonly<Record<string, string | null>>;
  minify: boolean;
  layers: boolean;
  rem: Required<CipoRemConfig>;
  colorMode: CipoColorMode;
  themeValidation: CipoThemeValidationMode;
  registerTypedThemeProperties: boolean;
  jit: Required<CipoJitConfig>;
  atomic: Required<CipoAtomicPromotionConfig>;
  scope: Required<CipoScopeConfig>;
  debugOverlay: { readonly enabled: boolean; readonly target: Document | ShadowRoot | HTMLElement | undefined; readonly position: "left" | "right" | "bottom" };
  onWarning?: ((warning: CipoWarning) => void) | undefined;
}

export interface RuntimeState {
  config: RuntimeConfig;
  sheet: CSSStyleSheet | null;
  insertedCss: Set<string>;
  atomicCache: Map<string, CipoAtomicRule>;
  artifactCache: Map<string, CipoCssResult>;
  inlineCache: Map<string, CipoInlineCssArtifact>;
  debugAtoms: Map<string, CipoAtomicRule>;
  themeKeys: Set<string>;
  shortThemeTokens: Map<string, string>;
  ambiguousThemeTokens: Map<string, readonly string[]>;
  helperRegistry: Map<string, CipoHelper>;
  nativeFunctionRegistry: Set<string>;
  aliasRegistry: Map<string, CipoAliasValue>;
  propertyAliasRegistry: Map<string, PropertyAliasDefinition>;
  propertyDefinitions: Map<string, Required<CipoPropertyDefinition>>;
  registeredProperties: Map<string, string>;
  variantRegistry: Map<string, readonly string[]>;
  warningSink: CipoWarning[];
  generatedCssText: string;
  layerHeaderInserted: boolean;
  themeVersion: number;
  configVersion: number;
  registryVersion: number;
  atomicUsageCounts: Map<string, number>;
  atomicSingleUseFallbacks: Map<string, CipoAtomicRule>;
}
