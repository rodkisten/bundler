# Fábrica Changelog


## Unreleased - Structural runtime/compiler convergence

### Breaking changes

- Removed the misleading `hydrate()` API. The previous implementation appended
  a second client-owned range after existing markup and did not perform SSR
  hydration. Use `mountPreservingChildren()` for that explicit behavior.
- Made `@rodkisten/fabrica` side-effect free. Importing the root package no
  longer installs `globalThis.Fabrica`, `$`, or `$el`; applications that require
  browser globals must import `@rodkisten/fabrica/browser` or call `install()`.
- Removed compiler APIs from the root entrypoint. Build integrations import
  `@rodkisten/fabrica/compiler`; generated browser code imports the runtime-only
  `@rodkisten/fabrica/compiler-runtime` helper surface.
- Removed wildcard package subpath exports. Only documented runtime, browser,
  compiler, compiler-runtime, and package metadata entrypoints are public.
- Object-prop `html` / `unsafeHTML` sinks now require an explicit `RawHtml`
  wrapper instead of accepting arbitrary strings.

### Architecture

- Reorganized the runtime into `core/`, `bindings/`, `render/`, `template/`,
  `directives/`, `compiler/`, and domain-focused `types/` modules.
- Reduced `render/dom.ts` to a compatibility facade. Root rendering, value and
  child-part materialization, template materialization, component-part binding,
  deferred child activation, payloads, cleanup, and HTML-result metadata now
  live in focused modules.
- Split the former monolithic template implementation into cache, source/micro-
  JSX transformation, and DOM-part compilation modules.
- Extracted keyed repeat reconciliation and LIS logic from the general directive
  runtime.
- Split the 600-line public/internal type surface into focused render,
  component, directive, template, event, debug, and DOM contracts while keeping
  `types.ts` as the stable public barrel.
- Broke the renderer/directive dependency cycle by injecting the minimal
  `appendValue` / owned-mount capabilities required by directive controllers.
- Replaced duplicated DOM prop semantics with a shared binding kernel used by
  interpreted templates, compiled templates, payloads, and spreads.
- Split the public instance factory into `api/` modules for API contracts,
  instance storage, component packs, and the legacy `$` bridge, leaving
  `public-api.ts` as a thin facade.
- Decomposed directive execution into focused controllers for `when`, keyed
  content, repeat, virtual repeat, portals, and suspense, with a minimal
  injected renderer host.
- Removed all runtime import cycles. The remaining recursive dependency is
  type-only and models the recursive `RenderValue` domain algebra.

### Compiler

- Replaced the textual tagged-template source scanner with a TypeScript AST
  transform.
- Split source lowering into AST hosting, lexical binding resolution, helper
  import management, IR serialization, HTML parsing, and a small transform
  orchestrator so compiler phases can evolve independently.
- Added syntactic import/alias resolution plus lexical-shadow checks so unrelated
  or shadowed `html` tags are not transformed.
- Preserved shebangs and directive prologues such as `"use client"` when helper
  imports are injected.
- Added collision-free helper binding generation and direct-component reference
  validation against visible value bindings.
- Added recursive AST lowering for nested Fábrica templates inside JavaScript
  template interpolation expressions.
- Consolidated build/runtime compact HTML parsing and made tag-end scanning
  quote-aware.
- Replaced the unbounded joined-string runtime template cache with callsite
  `WeakMap` caching and a bounded dynamic-string cache.
- Removed catch-all compiled-runtime fallback. Known unsupported shapes may
  deopt; unexpected materialization errors now surface instead of silently
  changing execution paths.

### Runtime/compiler parity

- Routed compiled plain attributes through the same reactive binding primitive
  as interpreted templates.
- Restored reactive compiled `.property`, `?boolean`, and `class:*` semantics.
- Routed compiled spreads through the canonical spread reconciler.
- Unified callback and object-ref lifecycle. Callback cleanup is preserved and
  object refs reset to `null` on disposal in all rendering paths.
- Added deep spread ownership for `attrs`, `dataset`, events, refs, and special
  attributes so stale nested state is removed correctly.
- Persisted special-attribute state across object-prop patches and added class/
  style map state reuse without retaining DOM nodes strongly.

### Package and build boundaries

- Added `@rodkisten/cipo/runtime-inline` and moved Fábrica `$css` / `$style`
  runtime compilation away from `@rodkisten/cipo/compiler`.
- Changed the Fábrica TypeScript build output to `dist/` instead of emitting
  JavaScript and declaration artifacts beside source files.
- Added explicit package exports for root, runtime, browser, compiler, and
  compiler-runtime entrypoints.
- Reworked global installation to capture previous globals at install time,
  restore custom aliases, support nested LIFO installs, avoid overwriting
  globals taken over by other libraries, and reset runtime options to defaults
  between installs.

### Diagnostics and source maps

- Added transform-aware, column-anchored source-map generation for Cipó/Fábrica
  build transforms while retaining the previous line-map helper for compatible
  consumers.

### Tests

- Added interpreted-versus-compiled parity coverage for reactive attributes,
  properties, booleans, conditional classes, spreads, ref cleanup, and object
  ref reset.
- Added AST compiler regressions for `"use client"`, shebangs, helper collisions,
  unrelated tags, aliases, lexical shadowing, nested templates, regex/comment
  interpolation syntax, quoted `>` attributes, and direct component references.
- Added spread regressions for stale nested `attrs` and `dataset` ownership.
- Added global installation lifecycle coverage for custom aliases, nested
  installs, external global takeover, and configuration reset.
- Added object-prop patch coverage for class/style reconciliation, special data
  attributes, and explicit raw HTML sinks.

### Documentation

- Added `ARCHITECTURE.md` with dependency, ownership, package-surface, cache, and
  runtime/compiler invariants.
- Added `COMPILER.md` documenting the AST pipeline, binding resolution,
  deoptimization rules, runtime boundary, and parity testing contract.


## Unreleased - Automatic event delegation and debug telemetry

### Fixed

- Kept `bind()` / `model()` form synchronization on direct element listeners.
  Two-way bindings no longer depend on delegated bubbling and now handle
  synthetic non-bubbling `input` / `change` events consistently.
- Re-enabled Fábrica store-view integration coverage after fixing Broto computed
  invalidation for synchronous DOM subscribers.

### Added

- Added automatic root-level delegation for safe bubbling template events such as `@click`, `@pointerup`, `@input`, `@change`, and custom bubbling events while preserving the existing declarative event API.
- Added `.direct` as an explicit opt-out. Capture listeners, passive listeners, and known non-bubbling events automatically keep native per-element listeners to preserve platform semantics.
- Added delegated `once` handling, native-like `event.currentTarget` lifetime, transient detached-tree roots that migrate on mount, ShadowRoot reconnection, and duplicate-dispatch protection across nested delegation roots.
- Routed spread event props through the shared event runtime so `onClick`, `on: { click }`, and `@click` use the same delegation model.
- Added debug event telemetry with `debugRecords()`, `clearDebugRecords()`, and `subscribeDebug()`, plus counters for delegated bindings, direct fallbacks, delegated dispatches, and handler calls. The bounded debug history stores string target descriptions instead of DOM references.

### Tests

- Added focused coverage for zero per-element listeners on delegated events, bubbling/modifier semantics, delegated `once`, direct fallbacks, ShadowRoot custom events, spread event props, and debug telemetry.

### Documentation

- Documented automatic delegation, `.direct`, fallback rules, unified spread/object event props, and the debug telemetry API.

## Unreleased
- Recursively lowers nested `html` / `jsx.html` templates inside interpolation expressions, preventing runtime template islands from surviving compiled DevTools panel builds and keeping each manifest entry's `dynamicValues` scoped to its own template.
- Fixed DevTools/Cipó remounts after `reset()` by making the runtime token bridge re-bootstrap idempotently through Cipó's own CSS dedupe, and aligned compact-build tests with production tuple/class-name output.

- DevTools compiled builds now keep Cipó configuration parsing out of the browser runtime while preserving Fábrica compiled-template mounting.
 - Production compiler compaction

### Performance

- Replaced verbose dynamic-template object AST payloads with compact numeric tuple instructions in compiled output.
- Added direct lexical component references for Vite production compilation, allowing component identifiers to be mangled and unused styled components to be tree-shaken instead of retained by display-name strings.
- Added a runtime-only `fabrica/runtime` entry used by DevTools so browser bundles do not traverse Fábrica compiler/source-scanner exports.
- Preserved backward compatibility with the previous object-shaped compiled template definitions.

### Tests

- Added compact tuple materialization coverage and updated compiled-build assertions for direct component references.
- Added recursive compiler and Vite integration coverage for nested `html` templates, manifest slot counts, indentation whitespace pruning, intentional inline spaces, and whitespace-sensitive elements.

## Unreleased - Literal and valueless data attributes

- Added valueless `:dataField` presence attributes.
- Added quoted literal data names such as `:"console-input-wrap"`.
- Added literal `:data` object keys through the `":name"` convention.
- Data attribute values now unwrap reactive values, remove only for `null`/`undefined`, and string-cast every other value including `false`.

## Unreleased

- Added the instance-local `event` helper with strongly typed properties for every DOM event name, including `event.click`, `event.pointerup`, `event.input`, and `event.keydown`.
- Added `FabricaEvent`, `FabricaEventHandler`, and augmentable `FabricaCustomEventMap` public types.
- Preserved the callable `event(handler)` compatibility form while making named event helpers zero-cost runtime identities. - props bags and property binding parity

### Added

- Added shorthand standalone props spread syntax: ``html`<RodButton ${props} />` ``. The browser runtime and compiled runtime both treat the interpolation as a spread only when it occupies a standalone opening-tag slot.
- Added component props bags through `props=${props}`. The bag is merged into component props rather than passed as a nested `props` field.
- Kept `.property=${value}` as an explicit property-only binding for native elements, custom elements and application-defined properties.

### Fixed

- Prevented object, callback, Node and fragment values used by component props from leaking into rendered output as `[object Object]`.
- Preserved nested Fábrica components and directives when compiled templates render through Cipó styled elements instead of letting the DOM adapter stringify their payloads.
- Decoded HTML entities in compiled styled-component children exactly once, matching normal browser template parsing for text such as `&lt;html&gt;`.
- Added runtime and compiler regression coverage for shorthand spreads, `props=${...}` bags and generic dot-property bindings.

## Unreleased - Runtime v2 cleanup collector and lazy repeat signals

### Performance

- Added a cleanup collector around template materialization. `render(host, html`...`)` now disposes direct root renders by running the exact collected cleanup nodes instead of recursively walking every descendant in the host. Fully static templates skip cleanup collection entirely.
- Added static-fragment metadata so direct root disposal for static trees is a plain `replaceChildren()` with no cleanup traversal. This targets short-lived render/benchmark/docs scenarios where the DOM tree is large but owns no effects.
- Added lazy repeat context signals. `repeat()` still exposes `item`, `index` and `key` as callable Broto-compatible signals, but the real signal object is now allocated only if user code reads or subscribes to it. Item renderers that only read `item()` no longer pay update costs for unused `index()` and `key()` signals during keyed reorders.

### Documentation

- Documented the Runtime v2 disposal model and repeat signal laziness as compatibility-preserving performance layers.



## Unreleased - Runtime v2 root and attribute instruction pass

### Performance

- Added a direct root-render fast path for materialized `DocumentFragment` values. `render(host, html`...`)` now mounts the compiled fragment directly on fresh or previously-direct roots instead of routing through the generic `ChildPart` range controller. Disposal still walks the mounted tree, runs registered cleanups and clears the host.
- Added static attribute/property/boolean/class fast paths. Non-reactive bindings now write directly without allocating an update closure, previous-value sentinel or effect wrapper. Reactive bindings keep the existing fine-grained effect path.
- Specialized `class` and `style` string writes to `className` and `style.cssText` for hot complex-attribute templates. Directive-based `classMap()` and `styleMap()` continue to use their diffing helpers.
- Added component child presence metadata at template compile time so component invocation avoids cloning and scanning empty slots. Static props can now be reused directly for slotless components.

### Documentation

- Documented the Runtime v2 root-render fast path, static binding instructions and remaining compatibility boundary around `html()` returning real `DocumentFragment` objects.

## Unreleased - forked registry and repeat hot-path repair

### Fixed

- Restored the forked registry fast path after the first Runtime v2 cache pass made inherited lookups pay the combined parent-version cost on every resolution.
- Split registry lookup caching into local/shared and inherited/forked paths so local component hits remain one `Map.get()` while inherited hits and misses are cached against the parent epoch.

### Performance

- Batched large keyed repeat reshuffles through one `DocumentFragment` move when the LIS shows that most ranges changed position. This keeps the public `repeat()` API unchanged while reducing DOM mutation storms for reversals, table sorts and drag-reorder style workloads.
- Kept the existing LIS path for small shuffles, append-only updates and mostly-stable lists so ordinary keyed updates still avoid unnecessary full-range moves.

### Documentation

- Documented the separated registry cache paths and the batched keyed-repeat fallback in the Fabrica README.


## Next - Runtime v2 execution plan

- Added a precompiled component dynamic-prop plan. Attributes and spreads that belong to component placeholders are now detected during template compilation, marked as component-owned parts, and passed directly to the component binder. The hot render path no longer builds a component path `Set`, no longer allocates a prop `Map`, and no longer reclassifies placeholder attributes every render.
- Added a registry L1 lookup cache for repeated named component resolution. Local registry hits, inherited hits and misses now remember the last normalized name together with the registry version, while all mutation APIs still invalidate the cache safely.
- Replaced the generic keyed repeat reorder pass with an LIS-based diff. Stable rows stay in place, new rows are inserted once, stale rows are removed once, and only non-LIS ranges are moved. This targets the keyed-list and virtual-list benchmarks without changing `repeat()` or `virtualRepeat()` APIs.
- Added per-record visual order metadata used by the keyed diff, append-only strategy and indexed strategy.
- Kept the public `html`, `jsx.html`, `render`, `repeat`, component registry and directive APIs unchanged.
- Documented the Runtime v2 performance model, including which work is now compile-time and which architectural targets remain future-safe without breaking the current DocumentFragment-returning API.

## Next - Runtime turbo pass

- Added a compiled component slot plan. Component placeholders now precompile their captured child parts, ordered child parts and static props during template compilation instead of recompiling and rereading attributes on every render.
- Skipped lifecycle microtask scheduling for components that do not register `onMount()`, removing one queued job from the common stateless component path.
- Added bounded trusted raw HTML template caching so repeated `rawHtml()` payloads clone cached template content instead of reparsing the same string each render.
- Added an inherited-registry lookup cache that only participates when a lookup misses the local registry and needs a parent registry. Local component resolution keeps the original one-`Map.get()` hot path.
- Added realm-local instance map caching for `getOrCreateFabrica()` so repeated named instance reuse avoids repeated symbol/global property lookups.
- Preserved all public APIs and existing component, directive, registry and render semantics.
- Verified with `tsc --noEmit`, the full Vitest suite, Fabrica-focused tests and the docs build in the local sandbox.

## Next - Instance registries and portable components

- Added `Fabrica.create()`, `Fabrica.getOrCreate()`, `Fabrica.createRegistry()` and instance-bound `html`, `render`, `mount`, `hydrate` and `component` APIs.
- Added live shared registries, isolated registries, snapshots and copy-on-write fork registries with a one-`Map.get()` common resolution path.
- Added `defineComponent()` for portable unregistered definitions, `instance.use()` for components/packs, and `createComponentPack()` with namespaces and include/exclude filters.
- Added component context access to `ctx.html`, `ctx.jsx`, `ctx.component`, `ctx.registry`, `ctx.instance` and the stable component name.
- Deprecated explicit `registerComponent(name, component)`, registry `registerComponent()` and implicit `component(function Name(){})` registration. Compatibility behavior remains and warnings are deduplicated per realm.
- Captured Fabrica runtime context inside reactive child parts and component-tag effects so delayed updates keep resolving against the instance that mounted them.
- Added instance, shared-registry, fork, pack, portability and deprecation tests plus benchmark cases for hot registry resolution and instance-local named rendering.



## Next

- Optimized component-name normalization and inherited-definition registration on hot registry paths, with cycle-safe parent graphs and zero duplicate overlay entries for identical inherited definitions.
- Fixed compound attribute interpolation on DOM and component tags. Values such as `class="${base} ${tone}"` and `title="Open ${label}"` now retain every static and dynamic segment instead of dropping later values or leaking internal marker text into the DOM.
- Component placeholders now distinguish exact raw props from compound string props, preserving objects, functions, signals, nodes and icon fragments only when the whole prop is a single interpolation.
- Marker-only and whitespace-only component bodies no longer become phantom `DocumentFragment` children, preventing self-closing and false conditional branches from leaking fragments into label/title fallbacks.
- Added focused template-compiler and nested toolbar-render tests covering reactive compound attributes, raw props, self-closing component boundaries, conditional children and marker leakage.

- Fixed self-closing interpolated component tags with props, so `<${Button} label=${label} />` emits an explicit template boundary instead of swallowing following siblings.
- Preserved author-provided camelCase dynamic component prop names such as `onClick`, `onPointerDown`, `selectedElement`, and `showCodePanel` through HTML template parsing.
- Self-closing components now receive `children: undefined` instead of an empty `DocumentFragment`; paired component tags still receive their real fragment children.
- Added React-like boolean rendering for component requests and bare component references: `${condition && Panel({ ...props })}` and `${condition && Panel}`.
- Added focused renderer tests covering consecutive toolbar components, ternary component fragments, reactive boolean branches, prop casing, events, and child semantics.

- Split DOM directive controllers into `dom-directives.ts` and spread prop diffing into `dom-spread.ts` to reduce `dom.ts` hot-spot complexity without changing public APIs.
- Added focused unit tests for directive controllers and spread prop diffing.
- Added template spread props syntax for DOM and component placeholder nodes: `html`<button ...${props}>Save</button>``.
- Added component event prop normalization so `<${Button} @click=${save}>` reaches the component as `props.onClick`.
- Fixed delegated events so root-level delegation no longer double-fires when a direct fallback is also needed for jsdom or isolated userscript worlds.
- Added kitchen-sink tests covering component event props, spread props and stale spread event listener cleanup.
- Added `html.jsx` micro-JSX syntax for registered string component tags: `html.jsx`<Dock />``.
- Added component registry APIs: `registerComponent`, `unregisterComponent`, `resolveComponent`, `listComponents`, and `clearComponents`.
- Added explicit parser-safe component fallback tag support with `<f-component name="Dock">...</f-component>`.
- Added missing-component fallback rendering as `<fabrica-component-error>` instead of silently stringifying or dropping unknown components.
- Added self-closing support for interpolation component tags: `html`<${Button} />``.
- Re-exposed Broto runtime primitives on the public Fabrica API: `signal`, `effect`, `computed`, `memo`, `batch`, `untrack`, `resource`, `configureScheduler`, `flushSync`, and `scheduleTask`.

- Added official component tag composition: `html`<${Button}>Save</${Button}>``.
- Changed `component()` to return lazy component render requests so context is captured at mount time.
- Added component materialization with ownership boundaries, lifecycle cleanup and child propagation.
- Added component placeholder compilation through `<template data-fabrica-component>`.
- Added dynamic child support inside component tags.
- Added Broto owner error propagation and boundary integration for effects, resources and lifecycle callbacks.
- Upgraded Broto resources with reactive source support, cache keys, retries, timeouts and owner error propagation.
- Added owner-scoped child part effects so fine-grained bindings can be disposed by DOM range lifecycle.

- Extracted reactivity ownership into Broto.
- Kept Fábrica focused on HTML, rendering, directives, DOM parts, components and hydration-oriented UI.
- Updated internal imports to consume Broto for renderer bindings and component context ergonomics.
- Removed public signal/effect/computed/batch exports from Fábrica's singleton API.

## 1.1.0

- Added component ownership boundaries powered by Broto.
- Added owned effects, resources, cleanup stack, mount/unmount lifecycle, context and refs.
- Added `boundary()` for render error recovery.
- Added public context helpers: `createContext`, `provide`, `useContext`.

## Unreleased

### Added

- Added the preferred `jsx.html` micro-JSX namespace for syntax highlighting friendly component templates while preserving `html.jsx` as a compatibility alias.
- Added `component(name, factory)` as a minifier-safe component definition form. The existing `component(factory)` API is unchanged.

### Fixed

- Fixed micro-JSX closing/self-closing component tag regex escaping so compiled bundles keep `\s` matching instead of degrading to literal `s`.
- Fixed dynamic component props in micro-JSX/component placeholders so values like `<TabButton plugin=${item} />` reach the component as the original runtime value instead of stringifying to `[object Object]`.
- Fixed a duplicated local declaration in property binding.

## Integration pass

- Added reactive component-tag invocation for dynamic props and spreads. Component tags such as `<${Button} tone=${tone}>` now re-run the component or styled factory when Broto signals used as props change.
- Improved adapter payload materialization with `attrs` and `dataset` support so Fabrica Elements payload output renders through Fábrica without losing data attributes.
- Added kitchen-sink coverage for Fabrica Elements payloads and Cipó styled components rendered through Fábrica component tags.

## Audit hardening pass

- Added integration coverage for Broto owner diagnostics and Fabrica Elements composition helpers.
- Documented non-breaking composition diagnostics for package-level audits.

## Staff-level composition helpers

- Added `bind`/`model` for two-way form bindings.
- Added `eventOptions` for explicit `addEventListener` options.
- Added `keyed`, `fragment`, `childrenToArray`, `slot`, and `memoView` helpers.
- Re-exported Broto primitives from the Fabrica package and browser API.
- Added focused feature tests for directives and event options.

## Unreleased - benchmark observatory

### Added

- Added a Vitest benchmark-mode kitchen sink with manual `document.createElement` baselines for twelve major rendering paths.
- Added a framework-neutral benchmark adapter contract with stable case identifiers for future renderer comparisons.
- Added branch-level JSON baselines and Markdown performance reports through the root benchmark pipeline.

## Named styled registry bridge

### Added

- Fabrica installation now announces registry readiness to independently bundled Fabrica Elements/Cipó styled factories.
- Normal `html`` ` automatically recognizes registered uppercase component tags through a bounded static-chunk scan; `jsx.html` remains available.
- Added integration tests for named Cipó styled components rendered by registry name without passing the function.

### Performance

- Added manual-versus-Fabrica benchmark cases for named styled registry rendering and styled component registration/unregistration.

## Reliable benchmark protocol

- Added same-runner baseline/current comparison with alternating order, median aggregation and per-row cross-round variation.
- Fabrica performance scoring now normalizes each adapter against its paired manual control and excludes controls from the overall score.
- Added fixture integrity coverage and semantically closer manual keyed/virtual list controls.

## Unreleased

- Prune indentation-only text nodes containing line breaks from runtime and compiled templates while preserving intentional single-space separators and whitespace-sensitive elements such as `pre`, `textarea`, `script`, and `style`.
- Keep runtime and compiled template materialization aligned through the same whitespace pruning pass.

## Unreleased

- Added registered self-closing component syntax through normal `html`, including `<NosUnicos />`.
- Added `$css` and `$style` element bindings backed by the Cipó inline runtime for string, object, artifact, signal, and reactive-function values.
- Added `:name`, `:data`, and camelCase-to-kebab-case dataset bindings.
- Added `[property]` bindings for reactive `style.setProperty()`, including CSS custom properties.

- Added required contexts, reactive signal contexts, portable context provider components and context diagnostics.
- Added `ctx.requireContext()`, `ctx.provideReactiveContext()`, `ctx.useReactiveContext()` and `ctx.requireReactiveContext()`.

## Unreleased

- Added `Context.Provider` to contexts created by `createFabricaContext()`, `createRequiredFabricaContext()` and `createReactiveFabricaContext()`.
- Added `useRequiredContext()` globally and as `ctx.useRequiredContext()`.
- Context providers now explicitly preserve store, service, object and signal identity without cloning, snapshotting or automatic unwrapping.
- Avoid redundant owner context writes when the provided reference is unchanged.
- Added coverage proving fine-grained store signal updates do not turn context into a broadcast rerender mechanism.
