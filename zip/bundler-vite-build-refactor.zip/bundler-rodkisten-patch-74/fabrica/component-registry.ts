import { warnDeprecated } from "./deprecations.js";
import type {
  ComponentLike,
  ComponentRegistry,
  ComponentRegistryOptions,
  RegistryCollision,
  RegistryRegistrationOptions,
} from "./types.js";

/** Normalizes names once at registry boundaries instead of on every render. */
export function normalizeComponentName(name: unknown): string {
  if (typeof name !== "string") return name == null ? "" : String(name).trim();
  const length = name.length;
  if (length === 0) return "";

  // Component names emitted by the template compiler are already normalized.
  // Avoid allocating a second string on the registry's hottest lookup path.
  const first = name.charCodeAt(0);
  const last = name.charCodeAt(length - 1);
  return first > 32 && last > 32 ? name : name.trim();
}

/**
 * Map-backed registry with an optional parent overlay.
 *
 * @remarks
 * Resolution is intentionally one `Map.get()` in the common case. Forked
 * registries add one predictable parent lookup and never clone component
 * functions. This keeps isolated plugins cheap while allowing copy-on-write
 * design-system overrides.
 */
export class FabricaComponentRegistry implements ComponentRegistry {
  readonly #components = new Map<string, ComponentLike>();
  readonly #inheritedResolveCache = new Map<string, { parentVersion: number; value: ComponentLike | undefined }>();
  #parent: ComponentRegistry | undefined;
  #version = 0;
  #combinedVersion = 0;
  #combinedParentVersion = -1;
  #lastLocalName = "";
  #lastLocalVersion = -1;
  #lastLocalValue: ComponentLike | undefined;
  #lastInheritedName = "";
  #lastInheritedParentVersion = -1;
  #lastInheritedValue: ComponentLike | undefined;
  readonly name: string;

  constructor(options: ComponentRegistryOptions = {}) {
    this.name = normalizeComponentName(options.name) || "registry";
    this.#parent = options.parent;

    if (options.entries) {
      for (const [name, component] of options.entries) {
        this.register(name, component, { collision: "replace" });
      }
    }
  }

  get parent(): ComponentRegistry | undefined {
    return this.#parent;
  }

  get size(): number {
    return this.#components.size;
  }

  get version(): number {
    const parentVersion = this.#parent?.version ?? 0;
    if (this.#combinedParentVersion !== parentVersion) {
      this.#combinedParentVersion = parentVersion;
      this.#combinedVersion = this.#version + parentVersion;
    }
    return this.#combinedVersion;
  }

  #clearResolutionCaches(): void {
    this.#inheritedResolveCache.clear();
    this.#combinedParentVersion = -1;
    this.#combinedVersion = this.#version;
    this.#lastLocalName = "";
    this.#lastLocalVersion = -1;
    this.#lastLocalValue = undefined;
    this.#lastInheritedName = "";
    this.#lastInheritedParentVersion = -1;
    this.#lastInheritedValue = undefined;
  }

  register<T extends ComponentLike>(
    name: string,
    component: T,
    options: RegistryRegistrationOptions = {},
  ): T {
    const normalized = normalizeComponentName(name);
    if (!normalized) {
      throw new Error("[Fabrica] Component registry needs a non-empty name.");
    }
    if (typeof component !== "function") {
      throw new TypeError("[Fabrica] Component registry expects a function component.");
    }

    const own = this.#components.get(normalized);
    if (own === component) return component;

    const collision = options.collision ?? "replace";
    const existing = own ?? this.#parent?.resolve(normalized);

    // Reusing an inherited definition should not allocate a redundant overlay
    // entry or invalidate registry consumers that watch the version counter.
    if (!own && existing === component) return component;

    if (existing && existing !== component) {
      if (collision === "keep") return existing as T;
      if (collision === "error") {
        throw new Error(`[Fabrica] Component registry collision for "${normalized}".`);
      }
      if (collision === "warn") {
        options.onWarning?.(
          `[Fabrica] Component "${normalized}" already exists in registry "${this.name}"; keeping the existing component.`,
        );
        if (!options.onWarning && typeof console !== "undefined") {
          console.warn(
            `[Fabrica] Component "${normalized}" already exists in registry "${this.name}"; keeping the existing component.`,
          );
        }
        return existing as T;
      }
    }

    if (this.#components.get(normalized) !== component) {
      this.#components.set(normalized, component);
      this.#version += 1;
      this.#clearResolutionCaches();
    }

    return component;
  }

  unregister(name: string): boolean {
    const removed = this.#components.delete(normalizeComponentName(name));
    if (removed) {
      this.#version += 1;
      this.#clearResolutionCaches();
    }
    return removed;
  }

  resolve(name: string): ComponentLike | undefined {
    const normalized = normalizeComponentName(name);
    if (!normalized) return undefined;

    // Hot path 1: local/shared registries. This intentionally does not read
    // `version`, because inherited version composition was the source of the
    // forked-registry regression: every lookup paid for parent bookkeeping even
    // when the component was local. Repeated same-name lookups use a tiny L1
    // cache, while alternating lookups fall back to a single Map.get().
    if (this.#lastLocalName === normalized && this.#lastLocalVersion === this.#version) {
      return this.#lastLocalValue;
    }

    const own = this.#components.get(normalized);
    if (own) {
      this.#rememberLocalResolve(normalized, own);
      return own;
    }

    const parent = this.#parent;
    if (!parent) {
      this.#rememberLocalResolve(normalized, undefined);
      return undefined;
    }

    // Hot path 2: forked registries. Cache inherited hits and misses against the
    // parent epoch only. This keeps copy-on-write registries as cheap as the
    // manual `own.get(name) ?? parent.get(name)` control without cloning maps.
    const parentVersion = parent.version;
    if (this.#lastInheritedName === normalized && this.#lastInheritedParentVersion === parentVersion) {
      return this.#lastInheritedValue;
    }

    const cached = this.#inheritedResolveCache.get(normalized);
    if (cached && cached.parentVersion === parentVersion) {
      this.#rememberInheritedResolve(normalized, parentVersion, cached.value);
      return cached.value;
    }

    const value = parent.resolve(normalized);
    this.#inheritedResolveCache.set(normalized, { parentVersion, value });
    this.#rememberInheritedResolve(normalized, parentVersion, value);
    return value;
  }

  has(name: string, ownOnly = false): boolean {
    const normalized = normalizeComponentName(name);
    return this.#components.has(normalized) || (!ownOnly && Boolean(this.#parent?.has(normalized)));
  }

  list(options: { inherited?: boolean } = {}): Map<string, ComponentLike> {
    const inherited = options.inherited !== false;
    const output = inherited && this.#parent
      ? this.#parent.list({ inherited: true })
      : new Map<string, ComponentLike>();

    for (const [name, component] of this.#components) output.set(name, component);
    return output;
  }

  clear(options: { inherited?: boolean } = {}): void {
    if (this.#components.size > 0) {
      this.#components.clear();
      this.#version += 1;
      this.#clearResolutionCaches();
    }
    if (options.inherited) this.#parent?.clear({ inherited: true });
  }

  "import"(
    source: ComponentRegistry,
    options: RegistryRegistrationOptions & { namespace?: string } = {},
  ): number {
    const namespace = normalizeComponentName(options.namespace);
    let imported = 0;

    for (const [name, component] of source.list({ inherited: true })) {
      this.register(namespace ? `${namespace}${name}` : name, component, options);
      imported += 1;
    }

    return imported;
  }

  fork(name = `${this.name}:fork`): ComponentRegistry {
    return new FabricaComponentRegistry({ name, parent: this });
  }

  snapshot(name = `${this.name}:snapshot`): ComponentRegistry {
    return new FabricaComponentRegistry({
      name,
      entries: this.list({ inherited: true }),
    });
  }

  setParent(parent: ComponentRegistry | undefined): void {
    let cursor = parent;
    while (cursor) {
      if (cursor === this) {
        throw new Error("[Fabrica] Component registry inheritance cannot contain cycles.");
      }
      cursor = cursor.parent;
    }

    if (this.#parent === parent) return;
    this.#parent = parent;
    this.#version += 1;
    this.#clearResolutionCaches();
  }

  #rememberLocalResolve(name: string, value: ComponentLike | undefined): void {
    this.#lastLocalName = name;
    this.#lastLocalVersion = this.#version;
    this.#lastLocalValue = value;
  }

  #rememberInheritedResolve(name: string, parentVersion: number, value: ComponentLike | undefined): void {
    this.#lastInheritedName = name;
    this.#lastInheritedParentVersion = parentVersion;
    this.#lastInheritedValue = value;
  }

  /** @deprecated Use `registry.register(name, component)` or `instance.use(component)`. */
  registerComponent<T extends ComponentLike>(name: string, component: T): T {
    warnDeprecated(
      "registry.registerComponent",
      "[Fabrica] registry.registerComponent(name, component) is deprecated. Use registry.register(name, component), instance.component(name, factory), or instance.use(definition).",
    );
    return this.register(name, component);
  }

  /** @deprecated Use `registry.unregister(name)`. */
  unregisterComponent(name: string): boolean {
    return this.unregister(name);
  }

  /** @deprecated Use `registry.resolve(name)`. */
  resolveComponent(name: string): ComponentLike | undefined {
    return this.resolve(name);
  }

  /** @deprecated Use `registry.list()`. */
  listComponents(): Map<string, ComponentLike> {
    return this.list();
  }

  /** @deprecated Use `registry.clear()`. */
  clearComponents(): void {
    this.clear();
  }
}

/** Creates an isolated or parent-backed component registry. */
export function createComponentRegistry(options: ComponentRegistryOptions = {}): ComponentRegistry {
  return new FabricaComponentRegistry(options);
}

/** Default singleton registry used by the compatibility/global API. */
export const defaultComponentRegistry = createComponentRegistry({ name: "default" });

/** Fast structural registry resolver used by instance and adapter APIs. */
export function resolveRegistry(value: unknown): ComponentRegistry | undefined {
  if (!value || typeof value !== "object") return undefined;
  const candidate = value as {
    registry?: unknown;
    resolve?: unknown;
    register?: unknown;
    resolveComponent?: unknown;
    registerComponent?: unknown;
  };

  if (candidate.registry) return resolveRegistry(candidate.registry);
  if (typeof candidate.resolve === "function" && typeof candidate.register === "function") {
    return value as ComponentRegistry;
  }

  if (typeof candidate.resolveComponent === "function" && typeof candidate.registerComponent === "function") {
    return createLegacyRegistryAdapter(value as LegacyRegistryShape);
  }

  return undefined;
}

type LegacyRegistryShape = {
  registerComponent(name: string, component: ComponentLike): unknown;
  unregisterComponent?(name: string): boolean;
  resolveComponent(name: string): ComponentLike | undefined;
  listComponents?(): Map<string, ComponentLike>;
  clearComponents?(): void;
};

const legacyRegistryAdapters = new WeakMap<object, ComponentRegistry>();

function createLegacyRegistryAdapter(legacy: LegacyRegistryShape): ComponentRegistry {
  const cached = legacyRegistryAdapters.get(legacy as object);
  if (cached) return cached;

  const adapter: ComponentRegistry = {
    name: "legacy-adapter",
    get size() {
      return legacy.listComponents?.().size ?? 0;
    },
    get version() {
      return 0;
    },
    register(name, component) {
      legacy.registerComponent(name, component);
      return component;
    },
    unregister(name) {
      return legacy.unregisterComponent?.(name) ?? false;
    },
    resolve(name) {
      return legacy.resolveComponent(name);
    },
    has(name) {
      return Boolean(legacy.resolveComponent(name));
    },
    list() {
      return legacy.listComponents?.() ?? new Map();
    },
    clear() {
      legacy.clearComponents?.();
    },
    "import"(source, options) {
      let count = 0;
      for (const [name, component] of source.list()) {
        this.register(options?.namespace ? `${options.namespace}${name}` : name, component, options);
        count += 1;
      }
      return count;
    },
    fork(name) {
      return new FabricaComponentRegistry({ name, parent: this });
    },
    snapshot(name) {
      return new FabricaComponentRegistry({ name, entries: this.list() });
    },
    setParent() {
      throw new Error("[Fabrica] Legacy registry adapters cannot change parent registry.");
    },
    registerComponent(name, component) {
      legacy.registerComponent(name, component);
      return component;
    },
    unregisterComponent(name) {
      return legacy.unregisterComponent?.(name) ?? false;
    },
    resolveComponent(name) {
      return legacy.resolveComponent(name);
    },
    listComponents() {
      return legacy.listComponents?.() ?? new Map();
    },
    clearComponents() {
      legacy.clearComponents?.();
    },
  };

  legacyRegistryAdapters.set(legacy as object, adapter);
  return adapter;
}

export type { RegistryCollision };
