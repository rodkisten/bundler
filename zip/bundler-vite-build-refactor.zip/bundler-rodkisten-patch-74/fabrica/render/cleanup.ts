import type { Cleanup } from "../types.js";

/** Cleanups attached to DOM nodes. WeakMap lets the browser collect removed nodes. */
const nodeCleanups = new WeakMap<Node, Cleanup[]>();

/** Nodes that received cleanups while a compiled fragment was being materialized. */
let activeCleanupCollector: Set<Node> | null = null;

/**
 * Runs a callback while collecting only the nodes that actually receive cleanup callbacks.
 *
 * @remarks
 * Root renders previously disposed by walking every descendant in the container.
 * That is safe, but expensive for short-lived benchmark and docs-style renders.
 * The collector keeps the public cleanup semantics intact while allowing the
 * direct root render path to dispose only the nodes that own effects/listeners.
 */
export function collectCleanupNodes<T>(callback: () => T): { value: T; nodes: Node[] } {
  const previous = activeCleanupCollector;
  const collector = new Set<Node>();
  activeCleanupCollector = collector;

  try {
    return { value: callback(), nodes: Array.from(collector) };
  } finally {
    activeCleanupCollector = previous;
  }
}

/** Disposes cleanup callbacks for a collected node list without walking descendants. */
export function disposeCollectedCleanups(nodes: readonly Node[]): void {
  for (let index = 0; index < nodes.length; index += 1) {
    const node = nodes[index];
    if (!node) continue;

    const cleanups = nodeCleanups.get(node);
    if (!cleanups) continue;

    for (let cleanupIndex = 0; cleanupIndex < cleanups.length; cleanupIndex += 1) {
      cleanups[cleanupIndex]?.();
    }

    cleanups.length = 0;
    nodeCleanups.delete(node);
  }
}

/**
 * Registers cleanup on a node.
 *
 * @remarks
 * Dynamic parts attach effect disposers to their boundary comments. Components
 * attach lifecycle disposers to their start boundary. This keeps cleanup tied to
 * real DOM ownership instead of a global registry that slowly turns swampy.
 *
 * @param node - Node that owns the cleanup.
 * @param cleanup - Cleanup callback.
 *
 * @example
 * ```ts
 * registerCleanup(element, () => element.removeEventListener("click", handler));
 * ```
 */
export function registerCleanup(node: Node, cleanup: Cleanup): void {
  let cleanups = nodeCleanups.get(node);

  if (!cleanups) {
    cleanups = [];
    nodeCleanups.set(node, cleanups);
  }

  cleanups.push(cleanup);
  activeCleanupCollector?.add(node);
}

/**
 * Disposes a node and all descendants.
 *
 * @param node - Root node to dispose.
 *
 * @example
 * ```ts
 * disposeTree(container);
 * container.replaceChildren();
 * ```
 */
export function disposeTree(node: Node): void {
  const cleanups = nodeCleanups.get(node);

  if (cleanups) {
    for (let index = 0; index < cleanups.length; index += 1) {
      cleanups[index]?.();
    }

    cleanups.length = 0;
    nodeCleanups.delete(node);
  }

  const children = node.childNodes;

  for (let index = 0; index < children.length; index += 1) {
    disposeTree(children[index] as Node);
  }
}

/**
 * Disposes an inclusive node range.
 *
 * @param start - Inclusive start boundary.
 * @param end - Inclusive end boundary.
 */
export function disposeRange(start: Node, end: Node): void {
  let current: Node | null = start;

  while (current) {
    const next: Node | null = current.nextSibling;
    disposeTree(current);

    if (current === end) {
      break;
    }

    current = next;
  }
}

/**
 * Clears nodes between two boundary comments while preserving the boundaries.
 *
 * @param start - Start boundary.
 * @param end - End boundary.
 */
export function clearRange(start: Comment, end: Comment): void {
  let current: Node | null = start.nextSibling;

  while (current && current !== end) {
    const next: Node | null = current.nextSibling;
    disposeTree(current);
    current.parentNode?.removeChild(current);
    current = next;
  }
}

/**
 * Removes an inclusive node range.
 *
 * @param start - Inclusive start boundary.
 * @param end - Inclusive end boundary.
 */
export function removeRange(start: Node, end: Node): void {
  let current: Node | null = start;

  while (current) {
    const next: Node | null = current.nextSibling;
    current.parentNode?.removeChild(current);

    if (current === end) {
      break;
    }

    current = next;
  }
}

/**
 * Moves an inclusive range before another node without recreating child nodes.
 *
 * @param start - Range start.
 * @param end - Range end.
 * @param before - Reference node.
 */
export function moveRangeBefore(start: Node, end: Node, before: Node): void {
  const parentNode = before.parentNode;

  if (!parentNode || start === before || end.nextSibling === before) {
    return;
  }

  const fragment = document.createDocumentFragment();
  let current: Node | null = start;

  while (current) {
    const next: Node | null = current.nextSibling;
    fragment.append(current);

    if (current === end) {
      break;
    }

    current = next;
  }

  parentNode.insertBefore(fragment, before);
}


/**
 * Appends an inclusive node range to a fragment, preserving node identity.
 *
 * @param start - Inclusive range start.
 * @param end - Inclusive range end.
 * @param fragment - Destination fragment.
 */
export function appendRangeToFragment(start: Node, end: Node, fragment: DocumentFragment): void {
  let current: Node | null = start;

  while (current) {
    const next: Node | null = current.nextSibling;
    fragment.append(current);

    if (current === end) {
      break;
    }

    current = next;
  }
}
