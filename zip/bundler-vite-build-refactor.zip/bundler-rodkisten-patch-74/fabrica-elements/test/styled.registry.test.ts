/** @vitest-environment jsdom */

import { describe, expect, it, vi } from 'vitest'
import { notifyFabricaRegistryReady } from '@rodkisten/fabrica-elements/registry'
import { createStyledFactory } from '@rodkisten/fabrica-elements/styled'
import type { ElementsComponent, ElementsComponentRegistry } from '@rodkisten/fabrica-elements/types'

function createRegistry(initial: Record<string, ElementsComponent> = {}): ElementsComponentRegistry & { values: Map<string, ElementsComponent> } {
  const values = new Map<string, ElementsComponent>(Object.entries(initial))
  return {
    values,
    registerComponent(name, component) {
      values.set(name, component)
      return component
    },
    unregisterComponent(name) {
      return values.delete(name)
    },
    resolveComponent(name) {
      return values.get(name)
    },
  }
}

function createFactory(registry?: ElementsComponentRegistry, collision: 'warn' | 'replace' | 'error' | 'ignore' = 'warn') {
  let id = 0
  return createStyledFactory<{ id: number }>({
    adapter: 'dom',
    autoRegister: true,
    collision,
    registry,
    createStyle() {
      id += 1
      return { className: `styled-${id}`, artifact: { id } }
    },
  })
}

describe('Fabrica Elements named styled registry', () => {
  it('auto-registers named tag components and exposes production metadata', () => {
    const registry = createRegistry()
    const styled = createFactory(registry)
    const Button = styled.button('Button').css`display: inline-flex;`

    expect(registry.values.get('Button')).toBe(Button)
    expect(Button.displayName).toBe('Button')
    expect(Button.registeredName).toBe('Button')
    expect(Button.tag).toBe('button')
    expect(Button.className).toBe('styled-1')
    expect(String(Button)).toBe('styled-1')
    expect(Button.artifact).toEqual({ id: 1 })
  })

  it('collects every styled component and deduplicates its static artifacts per factory', () => {
    const registry = createRegistry()
    const styled = createFactory(registry)
    const Button = styled.button('Button').css`display: inline-flex;`
    const Anonymous = styled.div.css`display: grid;`

    expect(styled.registry.size).toBe(2)
    expect(styled.registry.components).toEqual([Button, Anonymous])
    expect(styled.registry.artifacts).toEqual([Button.artifact, Anonymous.artifact])

    styled.registry.clear()
    expect(styled.registry.size).toBe(0)
    expect(styled.registry.components).toEqual([])
    expect(styled.registry.artifacts).toEqual([])
    expect(registry.values.get('Button')).toBe(Button)
  })

  it('supports direct styled syntax, attrs functions and polymorphic as', () => {
    const registry = createRegistry()
    const styled = createFactory(registry)
    const Action = styled.button('Action', {
      attrs: (props) => ({ type: 'button', 'aria-label': props.label }),
    })`display: inline-flex;`

    const button = Action({ label: 'Save', children: 'Save' }) as HTMLButtonElement
    expect(button.tagName).toBe('BUTTON')
    expect(button.type).toBe('button')
    expect(button.getAttribute('aria-label')).toBe('Save')
    expect(button.className).toBe('styled-1')

    const link = Action({ as: 'a', href: '/settings', label: 'Settings', children: 'Settings' }) as HTMLAnchorElement
    expect(link.tagName).toBe('A')
    expect(link.getAttribute('href')).toBe('/settings')
    expect(link.hasAttribute('as')).toBe(false)
  })

  it('preserves dynamic caller classes when adding generated classes', () => {
    const registry = createRegistry()
    const styled = createFactory(registry)
    const Panel = styled.div('Panel').css`display:block;`
    const panel = Panel({ class: () => 'caller active', 'aria-pressed': () => 'true' }) as HTMLDivElement

    expect(panel.className).toBe('caller active styled-1')
    expect(panel.className).not.toContain('=>')
    expect(panel.getAttribute('aria-pressed')).toBe('true')
  })

  it('preserves the anonymous backwards-compatible API', () => {
    const registry = createRegistry()
    const styled = createFactory(registry)
    const Anonymous = styled.button.css`display: block;`
    const DirectAnonymous = styled.div`display: grid;`

    expect(Anonymous({ children: 'A' })).toBeInstanceOf(HTMLButtonElement)
    expect(Anonymous.className).toBeDefined();
    console.log({ className: Anonymous.className, styled, registry })
    expect(DirectAnonymous({ children: 'B' })).toBeInstanceOf(HTMLDivElement)
    expect(registry.values.size).toBe(0)
  })

  it('exposes native tag helpers as own properties', () => {
    const registry = createRegistry()
    const styled = createFactory(registry)
    const Table = styled.table('Table').css`border-collapse: collapse;`

    expect(Object.prototype.hasOwnProperty.call(styled, 'table')).toBe(true)
    expect(registry.values.get('Table')).toBe(Table)
    expect(Table({ children: [] })).toBeInstanceOf(HTMLTableElement)
  })

  it('keeps tag helpers working when a prototype property has the same name', () => {
    const descriptor = Object.getOwnPropertyDescriptor(Function.prototype, 'table')
    Object.defineProperty(Function.prototype, 'table', {
      configurable: true,
      value: undefined,
    })

    try {
      const styled = createFactory()
      const Table = styled.table('ShadowedTable').css`border-collapse: collapse;`

      expect(Table({ children: [] })).toBeInstanceOf(HTMLTableElement)
    } finally {
      if (descriptor) Object.defineProperty(Function.prototype, 'table', descriptor)
      else delete (Function.prototype as Function & { table?: unknown }).table
    }
  })

  it('queues named components and flushes them when Fabrica connects later', () => {
    const styled = createFactory()
    const Panel = styled.section('DeferredPanel').css`display: grid;`

    expect(styled.pendingComponents()).toEqual(['DeferredPanel'])
    const registry = createRegistry()
    expect(styled.connectRegistry(registry)).toBe(1)
    expect(registry.values.get('DeferredPanel')).toBe(Panel)
    expect(styled.pendingComponents()).toEqual([])
  })


  it('flushes queued components through the cross-bundle registry-ready handshake', () => {
    const styled = createFactory()
    const Dialog = styled.dialog('DeferredDialog').css`display: grid;`
    const registry = createRegistry()

    notifyFabricaRegistryReady(registry)

    expect(registry.values.get('DeferredDialog')).toBe(Dialog)
    expect(styled.pendingComponents()).toEqual([])
  })

  it('implements warn, ignore, replace and error collision policies', () => {
    const Existing = (() => null) as ElementsComponent
    const warnings: string[] = []
    const registry = createRegistry({ Existing })
    const styled = createStyledFactory({
      adapter: 'dom',
      autoRegister: true,
      collision: 'warn',
      registry,
      onWarning(message) { warnings.push(message) },
      createStyle() { return { className: 'x', artifact: null } },
    })

    const Warned = styled.button('Existing').css`display:block;`
    expect(registry.values.get('Existing')).toBe(Existing)
    expect(warnings).toHaveLength(1)
    expect(Warned.register('Existing', 'ignore')).toBe('ignored')
    expect(Warned.register('Existing', 'replace')).toBe('replaced')
    expect(registry.values.get('Existing')).toBe(Warned)

    registry.values.set('Existing', Existing)
    expect(() => Warned.register('Existing', 'error')).toThrow(/collision/i)
  })

  it('styles and registers existing components without changing their prop contract', () => {
    const registry = createRegistry()
    const styled = createFactory(registry)
    const Base = vi.fn((props = {}) => ({ kind: 'base', props }))
    const Wrapped = styled(Base).named('WrappedButton').css`display:flex;`
    const output = Wrapped({ class: 'extra', value: 42 }) as { kind: string; props: Record<string, unknown> }

    expect(registry.values.get('WrappedButton')).toBe(Wrapped)
    expect(output.kind).toBe('base')
    expect(output.props.class).toBe('extra styled-1')
    expect(output.props.value).toBe(42)
  })

  it('provides an explicit component(name, { as }) facade', () => {
    const registry = createRegistry()
    const styled = createFactory(registry)
    const Card = styled.component('Card', { as: 'article', attrs: { role: 'region' } }).css`display:grid;`
    const node = Card({ children: 'Content' }) as HTMLElement

    expect(registry.values.get('Card')).toBe(Card)
    expect(node.tagName).toBe('ARTICLE')
    expect(node.getAttribute('role')).toBe('region')
  })
})

describe('Fabrica Elements polymorphic style inputs', () => {
  type Artifact = { id: string; className: string }

  function createArtifactFactory() {
    return createStyledFactory<Artifact>({
      adapter: 'dom',
      createStyle() {
        const artifact = { id: 'template', className: 'template-class' }
        return { className: artifact.className, artifact }
      },
      resolveStyle(input) {
        const artifact = input as Artifact
        return { className: artifact.className, artifact }
      },
    })
  }

  it('resolves static artifacts, arrays and prop-driven conditional artifacts', () => {
    const styled = createArtifactFactory()
    const base = { id: 'base', className: 'base-class' }
    const danger = { id: 'danger', className: 'danger-class' }
    const Button = styled.button('ArtifactButton')([
      base,
      (props) => Boolean(props.danger) && danger,
    ])

    expect(Button.className).toBe('base-class')
    expect(Button.artifact).toBe(base)
    expect(Button.artifacts).toEqual([base])
    expect(Button.dynamicStyles).toBe(true)

    const safe = Button({ children: 'Safe' }) as HTMLButtonElement
    const destructive = Button({ danger: true, children: 'Delete' }) as HTMLButtonElement
    expect(safe.className).toBe('base-class')
    expect(destructive.className).toBe('base-class danger-class')
  })

  it('deduplicates shared static artifacts across multiple registered styled components', () => {
    const styled = createArtifactFactory()
    const shared = { id: 'shared', className: 'shared-class' }
    const First = styled.div('First')(shared)
    const Second = styled.span('Second')(shared)

    expect(styled.registry.components).toEqual([First, Second])
    expect(styled.registry.artifacts).toEqual([shared])
    expect(styled.registry.artifacts).toBe(styled.registry.artifacts)
  })

  it('styles an existing DOM element from a precompiled artifact', () => {
    const styled = createArtifactFactory()
    const element = document.createElement('div')
    const artifact = { id: 'existing', className: 'existing-class' }
    const result = styled(element)(artifact)

    expect(result.element).toBe(element)
    expect(result.className).toBe('existing-class')
    expect(result.artifact).toBe(artifact)
    expect(element.className).toBe('existing-class')
  })
})
