import type { CipoAstNode, CipoDeclarationNode, CipoWarning } from '../types'
import { findTopLevelColon, parseFunctionCall, splitTopLevel, warn } from '../utils'
import { findMatching, isEscapedAt } from '../runtime-dsl/shared'
import { expandSmartDeclarationFunction, isNativeCssFunction, normalizePropertyDeclaration, parseGeneratedDeclarations } from '../values'
import { runtime } from '../runtime'
import { getStandaloneAliasName, stringifyAlias } from '../transform/index'


/**
 * Parses transformed CSS into Cipó's tiny AST.
 *
 * @remarks
 * This parser is intentionally small and fast. It is not a full CSS parser; it
 * only needs to understand the Cipó authoring surface:
 *
 * - declarations with optional semicolons;
 * - standalone aliases such as `glass` and `center`;
 * - function declarations such as `text(...)`;
 * - nested blocks such as `x:md { ... }` and `&:hover { ... }`;
 * - full stylesheet roots such as `.card { ... }` and `@media { ... }`.
 *
 * The important performance rule is that declarations are tokenized in one pass
 * instead of repeatedly splitting and reparsing the same text. This avoids the
 * Safari mobile freezes that appeared when semicolons were omitted.
 *
 * @param input - Transformed CSS source.
 * @param warnings - Warning sink for recoverable parser issues.
 * @returns Parsed AST nodes.
 *
 * @example Optional semicolons
 * ```ts
 * parseStylesheet(`
 *   px: 4
 *   py: 3
 *   bg: $brand
 * `, [])
 * // declaration nodes for padding-inline, padding-block and background
 * ```
 *
 * @example Nested runtime blocks
 * ```ts
 * parseStylesheet(`
 *   px: 4
 *
 *   x:md {
 *     px: 6
 *   }
 * `, [])
 * // declaration node + block node
 * ```
 */
export function parseStylesheet(input: string, warnings: CipoWarning[]): readonly CipoAstNode[] {
  return parseBlockBody(stripCssComments(input), warnings)
}

/**
 * Parses declarations/directives and nested blocks from a block body.
 *
 * @remarks
 * When a `{` is found, this parser separates the trailing block selector from
 * any declarations that came before it. That matters for semicolon-free Cipó:
 *
 * ```css
 * px: 4
 * py: 3
 * x:md {
 *   px: 6
 * }
 * ```
 *
 * Before this implementation, the buffer before `{` became one giant block name,
 * causing invalid CSS, warning storms and browser freezes. Now `px` and `py` are
 * flushed first, then `x:md` becomes the block name.
 *
 * @param input - CSS block body.
 * @param warnings - Warning sink.
 * @returns AST nodes.
 */
export function parseBlockBody(input: string, warnings: CipoWarning[]): readonly CipoAstNode[] {
  const sourceInput = stripCssComments(input)
  const nodes: CipoAstNode[] = []
  let buffer = ''
  let index = 0
  let quote: '"' | "'" | null = null

  while (index < sourceInput.length) {
    const char = sourceInput[index] ?? ''

    if (quote) {
      buffer += char
      if (char === quote && !isEscapedAt(sourceInput, index)) quote = null
      index += 1
      continue
    }

    if (char === '"' || char === "'") {
      quote = char
      buffer += char
      index += 1
      continue
    }

    if (char !== '{') {
      buffer += char
      index += 1
      continue
    }

    const { before, blockName } = splitBufferBeforeBlock(buffer)
    appendDeclarationsAndDirectives(nodes, before, warnings)
    buffer = ''

    if (!blockName) {
      warn(
        runtime,
        warnings,
        'missing-block-name',
        'A CSS block is missing its selector or runtime context.',
        sourceInput.slice(Math.max(0, index - 40), index + 40),
      )
    }

    const endIndex = findMatching(sourceInput, index, '{', '}')

    if (endIndex < 0) {
      warn(
        runtime,
        warnings,
        'unclosed-block',
        `Block "${blockName}" is missing a closing brace.`,
        sourceInput.slice(index),
      )
      break
    }

    const body = sourceInput.slice(index + 1, endIndex)
    nodes.push({
      type: 'block',
      name: blockName,
      body: parseBlockBody(body, warnings),
      source: `${blockName}{${body}}`,
    })

    index = endIndex + 1
  }

  appendDeclarationsAndDirectives(nodes, buffer, warnings)
  return nodes
}

/**
 * Parses a raw declaration list into nodes.
 *
 * @param input - Declaration source.
 * @param warnings - Warning sink.
 * @returns Declaration/directive nodes.
 *
 * @example
 * ```ts
 * parseDeclarations('px: 4\npy: 3', [])
 * // two declaration nodes
 * ```
 */
export function parseDeclarations(input: string, warnings: CipoWarning[]): readonly CipoAstNode[] {
  const nodes: CipoAstNode[] = []
  appendDeclarationsAndDirectives(nodes, stripCssComments(input), warnings)
  return nodes
}

/**
 * Parses declarations, directives and declaration helpers.
 *
 * @remarks
 * Semicolons are optional. Newlines are accepted as declaration separators when
 * the current statement is complete and parentheses/brackets are balanced.
 *
 * @param nodes - Output node list.
 * @param input - CSS declaration source.
 * @param warnings - Warning sink.
 * @returns Nothing.
 */
export function appendDeclarationsAndDirectives(nodes: CipoAstNode[], input: string, warnings: CipoWarning[]): void {
  const tokens = tokenizeDeclarations(input)

  for (const source of tokens) {
    if (!source) continue

    if (source.startsWith('@')) {
      const directive = parseDirective(source, warnings)
      if (directive) nodes.push(directive)
      continue
    }

    const functionDeclaration = parseDeclarationFunction(source, warnings)
    if (functionDeclaration.length > 0) {
      nodes.push(...functionDeclaration)
      continue
    }

    const colonIndex = findTopLevelColon(source)
    if (colonIndex <= 0) {
      const nativeCall = parseFunctionCall(source)
      if (nativeCall && isNativeCssFunction(nativeCall.name)) {
        continue
      }

      const aliasName = getStandaloneAliasName(source)
      if (aliasName && runtime.aliasRegistry.has(aliasName)) {
        nodes.push(...parseBlockBody(stringifyAlias(aliasName, warnings), warnings))
        continue
      }

      warn(runtime, warnings, 'invalid-declaration', `Invalid declaration "${source}".`, source)
      continue
    }

    const rawProperty = source.slice(0, colonIndex).trim()
    const rawValue = source.slice(colonIndex + 1).trim()
    nodes.push(...normalizePropertyDeclaration(rawProperty, rawValue))
  }
}

/**
 * Tokenizes declarations while allowing semicolons to be optional.
 *
 * @remarks
 * The tokenizer is line-aware and keeps nested function arguments intact. It is
 * deliberately conservative: it flushes on semicolons, on complete declaration
 * lines, and on standalone alias/helper lines.
 *
 * @param input - Declaration body.
 * @returns Declaration-like tokens.
 *
 * @example
 * ```ts
 * tokenizeDeclarations('px: 4\npy: 3\ntext(size: lg, lh: 1.1)')
 * // ['px: 4', 'py: 3', 'text(size: lg, lh: 1.1)']
 * ```
 */
export function tokenizeDeclarations(input: string): string[] {
  const output: string[] = []
  const stack: string[] = []
  let buffer = ''
  let quote: '"' | "'" | null = null
  let blockComment = false

  for (let index = 0; index < input.length; index += 1) {
    const char = input[index] ?? ''
    const next = input[index + 1] ?? ''

    if (blockComment) {
      if (char === '*' && next === '/') {
        blockComment = false
        index += 1
      }
      continue
    }

    if (quote) {
      buffer += char
      if (char === quote && !isEscapedAt(input, index)) quote = null
      continue
    }

    if (char === '/' && next === '*') {
      blockComment = true
      index += 1
      continue
    }

    if (char === '"' || char === "'") {
      quote = char
      buffer += char
      continue
    }

    const close = closingDelimiterFor(char)
    if (close) stack.push(close)
    else if (isClosingDelimiter(char) && stack.at(-1) === char) stack.pop()

    if (char === ';' && stack.length === 0) {
      pushToken(output, buffer)
      buffer = ''
      continue
    }

    if ((char === '\n' || char === '\r') && stack.length === 0) {
      if (isCompleteDeclarationToken(buffer)) {
        pushToken(output, buffer)
        buffer = ''
      } else if (buffer.trim()) {
        buffer += ' '
      }
      continue
    }

    buffer += char
  }

  pushToken(output, buffer)
  return output
}

function closingDelimiterFor(char: string): string | undefined {
  if (char === '(') return ')'
  if (char === '[') return ']'
  return undefined
}

function isClosingDelimiter(char: string): boolean {
  return char === ')' || char === ']'
}


/**
 * Parses old directive syntax.
 *
 * @param source - Directive source.
 * @param warnings - Warning sink.
 * @returns Directive node or null.
 */
export function parseDirective(source: string, warnings: CipoWarning[]) {
  const trimmed = source.trim()
  if (!trimmed.startsWith('@')) {
    warn(runtime, warnings, 'invalid-directive', `Invalid directive "${source}".`, source)
    return null
  }

  let nameEnd = 1
  while (nameEnd < trimmed.length && /[a-zA-Z0-9_-]/.test(trimmed[nameEnd] ?? '')) {
    nameEnd += 1
  }

  const name = trimmed.slice(1, nameEnd)
  const open = trimmed.indexOf('(', nameEnd)
  if (!name || open < 0 || trimmed.slice(nameEnd, open).trim()) {
    warn(runtime, warnings, 'invalid-directive', `Invalid directive "${source}".`, source)
    return null
  }

  const close = findMatching(trimmed, open, '(', ')')
  if (close < 0 || trimmed.slice(close + 1).trim()) {
    warn(runtime, warnings, 'invalid-directive', `Invalid directive "${source}".`, source)
    return null
  }

  return {
    type: 'directive' as const,
    name,
    args: splitTopLevel(trimmed.slice(open + 1, close), ','),
    source,
  }
}


/**
 * Supports function-like declaration helpers that remain useful, e.g. text(...).
 *
 * @remarks
 * This intentionally ignores normal declarations such as `bg: var(...)` and
 * `color: color-mix(...)`. Only true top-level helper calls are handled here.
 * That prevents warnings like "Unknown declaration helper bg: var(...)".
 *
 * @param source - Declaration candidate.
 * @param warnings - Warning sink.
 * @returns Generated declaration nodes.
 *
 * @example
 * ```ts
 * parseDeclarationFunction('text(size: lg, weight: 800)', [])
 * // font-size + font-weight declarations
 * ```
 */
export function parseDeclarationFunction(source: string, warnings: CipoWarning[]): CipoDeclarationNode[] {
  const call = parseFunctionCall(source)
  if (!call) return []

  const smart = expandSmartDeclarationFunction(call.name, call.args)
  if (smart) return parseGeneratedDeclarations(smart)

  if (call.name === 'text') {
    return normalizePropertyDeclaration('text', call.args.join(','))
  }

  if (isNativeCssFunction(call.name)) {
    return []
  }

  warn(runtime, warnings, 'unknown-function-declaration', `Unknown declaration helper "${call.name}(...)".`, source)
  return []
}

/**
 * Separates declarations before a nested block from the trailing block name.
 *
 * @param buffer - Text accumulated before `{`.
 * @returns Prefix declarations and block name.
 */
function splitBufferBeforeBlock(buffer: string): { readonly before: string; readonly blockName: string } {
  const trimmedEnd = buffer.replace(/\s+$/g, '')
  const splitIndex = findDeclarationBlockBoundary(trimmedEnd)

  if (splitIndex >= 0) {
    return {
      before: trimmedEnd.slice(0, splitIndex),
      blockName: trimmedEnd.slice(splitIndex).trim(),
    }
  }

  return { before: '', blockName: trimmedEnd.trim() }
}

/**
 * Finds the boundary between semicolon-free declarations and the following block name.
 *
 * @remarks
 * Selector lists are allowed to span lines in `sheet.css`, so a newline before
 * `{` is not automatically a declaration separator. Cipó only splits when the
 * prefix before the candidate block actually contains declaration-like tokens.
 *
 * @param input - Buffer immediately before `{`.
 * @returns Index where the block name starts, or -1 when the whole buffer is the block name.
 */
function findDeclarationBlockBoundary(input: string): number {
  const candidates: number[] = []
  const stack: string[] = []
  let quote: '"' | "'" | null = null

  for (let index = 0; index < input.length; index += 1) {
    const char = input[index] ?? ''

    if (quote) {
      if (char === quote && !isEscapedAt(input, index)) quote = null
      continue
    }

    if (char === '"' || char === "'") {
      quote = char
      continue
    }

    const close = closingDelimiterFor(char)
    if (close) stack.push(close)
    else if (isClosingDelimiter(char) && stack.at(-1) === char) stack.pop()

    if (stack.length === 0 && (char === ';' || char === '\n' || char === '\r')) {
      candidates.push(index)
    }
  }

  for (let cursor = candidates.length - 1; cursor >= 0; cursor -= 1) {
    const index = candidates[cursor]!
    const char = input[index] ?? ''
    const before = input.slice(0, index).trim()
    const after = input.slice(index + 1).trim()

    if (!after) return -1
    if ((char === '\n' || char === '\r') && getLastNonEmptyLine(before).endsWith(',')) continue
    if (before && containsDeclarationLikeStatement(before)) return index + 1
  }

  return -1
}

function getLastNonEmptyLine(input: string): string {
  const lines = input.split(/\r?\n/g)
  for (let index = lines.length - 1; index >= 0; index -= 1) {
    const line = lines[index]?.trim() ?? ''
    if (line) return line
  }
  return ''
}

/**
 * Checks whether a text chunk contains declaration-like statements.
 *
 * @param input - Candidate declaration chunk.
 * @returns Whether at least one parsed token is declaration-like.
 */
function containsDeclarationLikeStatement(input: string): boolean {
  const tokens = tokenizeDeclarations(input)

  for (let index = 0; index < tokens.length; index += 1) {
    const token = tokens[index]
    if (!token) continue
    if (findTopLevelColon(token) > 0) return true
    if (parseFunctionCall(token)) return true
    if (/^\$?[a-zA-Z_][\w-]*$/.test(token.trim())) return true
  }

  return false
}


/** Removes CSS block comments without touching quoted strings. */
function stripCssComments(input: string): string {
  let output = ''
  let quote: '"' | "'" | null = null
  let escaped = false

  for (let index = 0; index < input.length; index += 1) {
    const char = input[index]
    const next = input[index + 1]

    if (quote) {
      output += char
      if (escaped) escaped = false
      else if (char === '\\') escaped = true
      else if (char === quote) quote = null
      continue
    }

    if (char === '"' || char === "'") {
      quote = char
      output += char
      continue
    }

    if (char === '/' && next === '*') {
      index += 2
      while (index < input.length && !(input[index] === '*' && input[index + 1] === '/')) index += 1
      if (index < input.length) index += 1
      output += '\n'
      continue
    }

    output += char
  }

  return output
}

/**
 * Appends one token when it contains meaningful content.
 *
 * @param output - Token list.
 * @param value - Current buffer value.
 * @returns Nothing.
 */
function pushToken(output: string[], value: string): void {
  const token = value.trim()
  if (token) output.push(token)
}

/**
 * Checks whether a line-level token is complete enough to flush.
 *
 * @param value - Current token candidate.
 * @returns Whether the token should be emitted.
 */
function isCompleteDeclarationToken(value: string): boolean {
  const token = value.trim()
  if (!token) return false
  if (token.endsWith(',') || token.endsWith(':')) return false
  if (findTopLevelColon(token) > 0) return true
  const call = parseFunctionCall(token)
  if (call) return true
  return /^[a-zA-Z_][\w-]*$/.test(token)
}
